# SPDX-License-Identifier: GPL-3.0-or-later
"""What the sidebar says, in plain words (SPEC §5.5: the user never wonders what the assistant did).
No GTK here, so it can be tested anywhere. English for the Alpha; translations come with D25's UI work.
"""

from __future__ import annotations

import json
import re

TOPICS = {
    "overview": "what kind of computer this is", "storage": "the disk space", "network": "the network",
    "updates": "the updates", "printers": "the printers", "sound": "the sound", "display": "the screens",
    "battery": "the battery", "drivers": "the drivers", "account": "your account", "memory": "the memory in use",
    "temperature": "the temperatures", "time": "the clock",
}

UPDATE_READY = "An update is installed. The assistant restarts into it on a short break, or now:"
UPDATE_NOW = "Restart now"
UPDATED = "The assistant was updated to the new version."

STATES = {  # State property -> (dot colour class, words)
    "idle": ("ok", "Ready"),
    "thinking": ("busy", "Answering…"),
    "loading": ("busy", "Getting ready…"),
    "off": ("off", "Resting (starts when you ask)"),
    "error": ("bad", "Not available"),
    "offline": ("bad", "Not running"),
}


def action(tool: str, args: dict, result: str = "") -> tuple[str, str]:
    """(icon name, words) for a tool the guide used."""
    if tool == "lookup_help":
        return "system-search-symbolic", "Looked it up in the built-in help"
    if tool == "terminal":
        return "utilities-terminal-symbolic", "Looked at your terminal (changes nothing)"
    if tool == "inspect_system":
        what = f"Checked {TOPICS.get(args.get('topic', ''), 'this computer')} (changes nothing)"
        n = len(_problems(result))
        if n:
            what += f" — found {n} problem{'s' if n > 1 else ''}"
        return ("dialog-warning-symbolic" if n else "computer-symbolic"), what
    if tool == "open_app":
        try:
            opened = json.loads(result).get("opened") if result else None
        except ValueError:
            opened = None
        return ("system-run-symbolic", f"Opened {opened}") if opened else \
               ("dialog-warning-symbolic", "Tried to open a program, but couldn't")
    if tool == "request_install":
        return "dialog-information-symbolic", "Installing through the assistant comes in a later version"
    if tool == "make_spreadsheet":
        try:
            made = json.loads(result).get("created") if result else None
        except ValueError:
            made = None
        if made:
            return "x-office-spreadsheet-symbolic", f"Made a new spreadsheet: {made}"
        return "dialog-warning-symbolic", "Tried to make a spreadsheet, but couldn't"
    if tool == "open_video":
        try:
            opened = json.loads(result).get("opened") if result else None
        except ValueError:
            opened = None
        title = opened or args.get("title") or "the video"
        return "video-x-generic-symbolic", (f"Opened “{title}” in Firefox" if opened else f"Opening “{title}” in Firefox…")
    if tool == "compose_email":
        try:
            opened = json.loads(result).get("opened") if result else None
        except ValueError:
            opened = None
        if opened:
            return "mail-message-new-symbolic", f"Wrote a draft email in {opened} (not sent: you add the address and send it)"
        return "dialog-warning-symbolic", "Tried to open a draft email, but couldn't"
    return "dialog-information-symbolic", f"Used {tool}"


def status_line(state: str, status: dict) -> tuple[str, str, str]:
    """(dot class, first line, second line) for the header."""
    dot, words = STATES.get(state, ("bad", state))
    build = status.get("build", "")
    where = {"cuda": "graphics card", "vulkan": "graphics card", "cpu": "processor"}.get(build, "")
    ctx = status.get("context", 0)
    model = status.get("model", "") or "Cin-MinAI guide"
    second = model + (f" · {where}" if where else "") + (f" · {ctx // 1024}K" if ctx else "")
    if status.get("document"):
        second += "\n" + sees(status["document"])
    detail = status.get("detail", "")
    if state == "loading" and detail.startswith("stick:"):  # the live USB's straight read of the model
        return dot, words, model + "\n" + t("stick_read", pct=detail[6:])
    if status.get("reduced"):
        second += f"\n{status['reduced']}"
    elif state == "error" and detail:
        second += f"\n{detail}"
    return dot, words, second


def waiting(state: str, build: str, detail: str = "") -> str:
    """What to show in an answer that hasn't started yet."""
    if state == "loading" and detail.startswith("stick:"):
        return t("stick_wait")
    if state == "loading":
        return "Getting the assistant ready. The first time can take a minute or two."
    if build == "cpu":
        return "Reading your question… (on the processor this can take up to a minute)"
    return "Reading your question…"


# --- commands to copy (PLAN D53) -----------------------------------------------------------------------

FENCE = re.compile(r"```[a-z]*\n(.+?)\n?```", re.S)
INLINE = re.compile(r"`((?:sudo |systemctl |apt |dkms |uname|fsck |echo \d+ \| sudo "
                    # M3: ordinary shell commands, now that answers can be about the person's terminal
                    r"|python3? |pip3? |\.venv/bin/|source |\. \.venv|cd |chmod |ls\b|pwd\b|mkdir |git |make\b|gcc |"
                    r"bash |\./)[^`\n]*)`")


def _problems(result: str) -> list[dict]:
    try:
        r = json.loads(result) if result else {}
    except ValueError:
        return []
    return r.get("problems_found", []) if isinstance(r, dict) else []


def commands_in_result(result: str) -> list[dict]:
    """Commands the diagnostics handed over with a tool result: {"command", "explain", "undo"}."""
    return [{"command": p["command"], "explain": p.get("command_explained", ""), "undo": p.get("undo", "")}
            for p in _problems(result) if p.get("command")]


def commands_in_text(text: str) -> list[dict]:
    """Commands the guide wrote itself: a fenced block, or a command in backticks. A block of several commands
    becomes one card per command (Ian's venv test, 2026-10-04: four commands, rm -rf among them, in one card that
    a single Enter would have run), indentation removed; a line ending in a backslash continues on the next."""
    found = []
    for block in FENCE.findall(text):
        line_buf = ""
        for line in block.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.endswith("\\"):
                line_buf += line[:-1].rstrip() + " "
                continue
            found.append(line_buf + line)
            line_buf = ""
        if line_buf.strip():
            found.append(line_buf.strip())
    found += [c.strip() for c in INLINE.findall(text)]
    return [{"command": c, "explain": "", "undo": ""} for c in found if c]


def merge_cards(*lists: list[dict]) -> list[dict]:
    """One card per command, the first (the one with an explanation) wins."""
    out, seen = [], set()
    for card in (c for lst in lists for c in lst):
        key = " ".join(card["command"].split())
        if key not in seen:
            seen.add(key)
            out.append(card)
    return out


DELETES = re.compile(r"\brm\s+(-\w+\s+)*(?P<what>[^\s;|&]+)")


def card_notes(card: dict, terminal: bool = False) -> list[str]:
    notes = []
    if card.get("explain"):
        notes.append(f"What it does: {card['explain']}")
    if card.get("undo"):
        notes.append(f"To undo: {card['undo']}")
    gone = DELETES.search(card["command"])
    if gone:
        notes.append(f"This deletes {gone.group('what')}. Make sure that's what you want gone.")
    if card["command"].lstrip().startswith("sudo") or "| sudo" in card["command"]:
        notes.append("It asks for your password: that's you saying yes.")
    notes.append("To terminal puts it at your prompt; press Enter there to run it." if terminal else
                 "Copy, then paste it in the Terminal with Ctrl+Shift+V and press Enter.")
    return notes


# --- document edits: the preview card (SPEC §7.8) ------------------------------------------------------

GRID_ROWS, GRID_COLS, CELL_CHARS = 8, 5, 14


def _cell(v) -> str:
    s = "" if v is None else str(v)
    if s.endswith(".0") and s[:-2].lstrip("-").isdigit():
        s = s[:-2]
    return s if len(s) <= CELL_CHARS else s[:CELL_CHARS - 1] + "…"


def grid(rows) -> list[list[str]]:
    """A range for the card: at most GRID_ROWS x GRID_COLS, with … where it's cut."""
    out = [[_cell(v) for v in r[:GRID_COLS]] + (["…"] if len(r) > GRID_COLS else []) for r in rows[:GRID_ROWS]]
    if len(rows) > GRID_ROWS:
        out.append(["…"])
    return out


def preview_parts(pv: dict) -> dict:
    """{"title", "kind": "text" | "grid" | "slide", "before", "after"} for the card."""
    before, after = pv.get("before"), pv.get("after")
    title = pv.get("summary", "A change to your document")
    if isinstance(after, list):
        return {"title": title, "kind": "grid", "before": grid(before or []), "after": grid(after)}
    if isinstance(after, dict):
        show = lambda d: "\n".join(x for x in ((d or {}).get("title", ""), (d or {}).get("body", "")) if x)
        return {"title": title, "kind": "slide", "before": show(before), "after": show(after)}
    return {"title": title, "kind": "text", "before": str(before or ""), "after": str(after or "")}


def decided(result: dict | None, error: str | None) -> str:
    if error:
        return f"Not changed: {error}"
    if result and result.get("applied"):
        return "Done. Press Ctrl+Z in LibreOffice to undo it in one step."
    return "Discarded. Your document is unchanged."


def sees(document: str) -> str:
    return f'Sees: document "{document}"' if document else ""


ASKED = {  # LibreOffice's Assistant menu -> the question the sidebar asks (SPEC §7.6)
    "ask-selection": None,  # the user types the question
    "rewrite-selection": "Rewrite the selected text so it reads better.",
    "explain-formula": "Explain the formula in the selected cell in simple words.",
    "summarize": "Summarize this document in a few sentences.",
}


# --- writing projects (D54) ----------------------------------------------------------------------------

PROJECT_HELLO = ("Tell me about your story: the people, the places, what happens, how it should feel. I'll keep "
                 "notes. When you're ready, click Write it up.")


def project_bar(title: str) -> str:
    return f"Writing: {title}" if title else ""


def outline_lines(outline: dict) -> list[str]:
    """The plan by the story circle's steps (D56): each step's name, then its scenes."""
    out, step = [], None
    for i, s in enumerate(outline.get("scenes", []), 1):
        if s.get("step_name") and s["step_name"] != step:
            step = s["step_name"]
            out.append(f"{step}:")
        out.append(f"{'  ' if step else ''}{i}. {s.get('title', '')}: {s.get('what_happens', '')}")
    return out


# --- the story circle (D56) ------------------------------------------------------------------------------

SHAPES = ["A story in one chapter"] + [f"A story over {n} chapters" for n in range(2, 9)]


def shape_index(info: dict) -> int:
    return 0 if info.get("shape") != "chapters" else max(0, min(7, int(info.get("chapters", 4)) - 1))


def shape_settings(index: int) -> dict:
    return {"shape": "chapter"} if index <= 0 else {"shape": "chapters", "chapters": index + 1}


def circle_lines(info: dict) -> list[str]:
    circle = info.get("circle", {})
    out = ["The story circle (Dan Harmon's):"]
    for i, s in enumerate(info.get("steps", []), 1):
        out.append(f"  {i}. {s['name']} ({s['means']}): " + (" ".join(circle.get(s["key"], [])) or "not yet"))
    return out


STEP_NAMES = {"you": "You", "need": "Need", "go": "Go", "search": "Search", "find": "Find", "take": "Take",
              "return": "Return", "change": "Change"}
QUOTES = "\"'“”„«» "  # the model's own quote marks around a quote (2026-10-01: ""Elena, the founder…"")
STATUS_MARKS = {"written": "✓", "partly written": "◐", "planned": "·", "missing": "○"}


def review_title(review: dict) -> str:
    if review.get("chapter"):
        return f"Before chapter {review['chapter']} of {review.get('of')}: where the story is"
    return "Before writing: where the story is"


def review_step(k: str, s: dict) -> str:
    shown = f' — "{s["evidence"].strip(QUOTES)}"' if s.get("status") in ("written", "partly written") and s.get("evidence") else ""
    return f"{STEP_NAMES.get(k, k)} ({s.get('status', '')}): {s.get('what', '')}{shown}"


def review_steps(review: dict) -> list[tuple[str, str, bool]]:
    """The card's tick boxes (D57): (step, its line, ticked = the review found it written). The writer's ticks
    decide where the chapter starts."""
    return [(k, review_step(k, s), s.get("status") == "written") for k, s in review.get("steps", {}).items()]


def would_cover(review: dict, ticked) -> list[str]:
    """Where the chapter starts with these ticks: the first step not ticked, the steps left paced over the chapters
    left — the same rule as the daemon's (writer.next_steps; a test keeps them equal)."""
    order = list(STEP_NAMES)
    chapter, of = review.get("chapter"), review.get("of") or 1
    if not chapter:
        return order
    start = next((i for i, k in enumerate(order) if k not in ticked), len(order))
    left = order[start:] or order[-1:]
    return left[:-(-len(left) // max(1, of - chapter + 1))]


def cover_line(review: dict, steps: list[str]) -> str:
    if not review.get("chapter"):
        return ""
    return f"Chapter {review['chapter']} would cover: " + ", ".join(STEP_NAMES.get(k, k) for k in steps) + "."


def review_lines(review: dict, steps: bool = True) -> list[str]:
    """The review before a chapter (D57), in the order a writer reads it; steps=False leaves out the circle and
    the chapter line (the card shows them as tick boxes and a line that follows them)."""
    out = []
    if steps:
        out.append("The story circle:")
        out += [f"  {STATUS_MARKS.get(s.get('status'), '·')} {review_step(k, s)}" for k, s in review.get("steps", {}).items()]
    if review.get("characters"):
        out.append("The characters:")
        out += [f"  • {c.get('name', '')}, at {STEP_NAMES.get(c.get('step'), c.get('step', ''))}: {c.get('where', '')}"
                for c in review["characters"]]
    if review.get("missing"):
        out.append("Still missing:")
        out += [f"  • {m}" for m in review["missing"]]
    if review.get("questions"):
        out.append("Questions for you:")
        out += [f"  • {q}" for q in review["questions"]]
    nxt = review.get("next_steps", [])
    if steps and review.get("chapter") and nxt:
        out.append(cover_line(review, nxt))
    return out


# --- the manuscript (D58) ---------------------------------------------------------------------------------

MANUSCRIPT_TIP = "Your chapters as they are now, in the format agents and publishers expect (.odt and Word)."
MANUSCRIPT_INTRO = ("This puts your chapters, as they are now (your own edits included), into one new document in "
                    "standard manuscript format: a title page, double spacing, a page header with your name, each "
                    "chapter on a new page. You get it as a LibreOffice file and as a Word file, which most agents "
                    "and publishers ask for. Your drafts stay as they are.")


def manuscript_done(res: dict) -> str:
    import os
    name = os.path.basename(res.get("odt", ""))[:-4]
    n = res.get("chapters", 0)
    return (f"Your manuscript is ready: {n} chapter{'s' if n != 1 else ''}, {res.get('words', 0):,} words, "
            f"{res.get('paper', '')} paper. It's open in Writer and saved in the project folder as \"{name}\", "
            ".odt and .docx (for Word).")


# --- a bigger model for writing (D60) ---------------------------------------------------------------------

def offer_title(o: dict) -> str:
    return "Your computer can run a stronger writing model"


def offer_lines(o: dict) -> list[str]:
    lo, hi = o.get("tok_s", [0, 0])
    lines = [f"{o.get('model', '')}: {o.get('why', '')}.",
             f"Here it would run {o.get('mode', '')}, about {lo * 45:.0f}-{hi * 45:.0f} words a minute."]
    if o.get("downloaded"):
        lines.append("It's already downloaded.")
    elif o.get("parked_on"):
        lines.append(f"It's on {o['parked_on']}: it'll be copied back to this computer and checked, no download needed.")
    else:
        lines.append(f"The download is {o.get('size', 0) / 2**30:.1f} GB from Hugging Face, checked against its checksum "
                     "before it's used. Nothing is sent or fetched until you click Download.")
    if not o.get("space_ok", True):
        lines.append("There isn't enough free disk space for it right now.")
    return lines


def download_progress(p: dict) -> str:
    if p.get("testing"):
        return f"Checked. Testing {p.get('model', '')} on this computer…"
    verb = "Copying" if p.get("copy") else "Downloading"
    return f"{verb} {p.get('model', '')}: {p.get('have_gb', '0')} of {p.get('total_gb', '?')} GB"


def download_done(p: dict) -> str:
    return f"{p.get('model', '')} is ready: {p.get('measured', 0):.0f} tokens a second here."


def model_line(in_use: dict | None) -> str:
    if not in_use:
        return "Writing uses the built-in guide."
    m = in_use.get("measured")
    return f"Writing uses {in_use.get('model', '')}" + (f" ({m:.0f} tokens a second here)." if m else ".")


def next_chapter_line(info: dict) -> str:
    if info.get("shape") != "chapters":
        return "Write it up reviews your notes, then plans the whole circle in one chapter."
    return (f"Write it up reads the story so far, shows where it is on the circle, then plans chapter "
            f"{info.get('next_chapter')} of {info.get('chapters')}.")


def draft_progress(p: dict) -> str:
    return f"Writing scene {p.get('scene')} of {p.get('of')}: {p.get('title', '')}"


def draft_done(res: dict) -> str:
    pages = -(-int(res.get("lines", 0)) // 28)
    return f"Saved {res.get('shown', '')}: {res.get('words', 0)} words, about {pages} pages"


NOTE_LABELS = {"facts": "Facts", "characters": "Characters", "places": "Places", "ideas": "Ideas"}


def notes_lines(notes: dict) -> list[str]:
    out = []
    for k, label in NOTE_LABELS.items():
        if notes.get(k):
            out.append(f"{label}:")
            out += [f"  • {n}" for n in notes[k]]
    return out or ["No notes yet: tell me about your story."]


# --- the journal (D55) -----------------------------------------------------------------------------------

JOURNAL_HELLO = "How was your day? Tell me whatever you'd like to remember. I'll only ask, never judge."


def entry_label(e: dict) -> str:
    when = e.get("when", "").replace("T", " ")[:16]
    return f"🔒 {when}  (private)" if e.get("private") else f"{when}  {e.get('title', '')}"


def journal_written(e: dict) -> str:
    return ("Entry written and locked" if e.get("private") else f"Entry written: {e.get('title', '')}") + \
        f" ({e.get('words', 0)} words)"


# --- web search (D55, SPEC §7.5) ---------------------------------------------------------------------------

# --- six languages for update 5's features (D25): the search card, the news watch, standing tasks, keys ---------
# Written by Claude (not a native speaker of es/pt/fr/de/ja): wants a native speaker's review (D36). The rest of the
# sidebar is still English (the Alpha's note above).
T = {
    "en": {'h_helper': 'a helper file, not a model', 'h_more': 'More models', 'h_note': 'Your search words are sent to Hugging Face, and nothing else.', 'h_search': 'Search', 'h_open': 'Download…', 'h_hint': 'e.g. qwen coder', 'h_lic': 'licence: {lic} (not reviewed by us)', 'h_no_lic': 'no licence stated', 'h_dl': '{n} downloads', 'h_none': 'Nothing found.', 'h_check': 'Does it run here?', 'h_checking': 'Checking…', 'h_parts': 'in parts: not offered yet', 'h_mmproj': 'a picture reader: not offered on its own', 'h_nosum': 'no checksum: not offered', 'h_gated': 'asks you to sign in at Hugging Face: not offered yet', 'h_no_job': 'No job yet', 'h_get': 'Download ({gb} GB)', 'h_drives': 'Look on connected drives', 'h_no_drives': 'No models on connected drives.', 'h_bring': 'Bring in ({gb} GB)', 'h_remove': 'Remove', 'h_used': 'used for {jobs}', 'h_runs_nothing': "It doesn't run on this computer.", 'h_room': 'Not enough free space: {gb} GB needed.', 'h_have': 'Already in the model folder.', 
           'models': 'Models', 'job_system': 'Help and the system', 'job_coding': 'Writing code (AICUI)', 'job_writing': 'Writing', 'job_vision': 'Pictures and video', 'job_junior': 'Laying out code', 'job_review': 'Reviewing', 'job_research': 'Research papers', 'm_locked': "Stays with the guide: it holds the system's tools.", 'm_soon': 'Comes when models can hand work to each other.', 'm_ours': 'our pick', 'm_yours': 'your choice', 'm_use_ours': 'Our pick', 'm_fast': 'runs well here', 'm_slow': 'runs slowly here', 'm_no_fit': "doesn't run here", 'm_here': 'On this computer', 'm_system': 'comes with the system', 'm_parked': 'parked on {drive}', 'm_free': '{gb} GB free for models', 'm_reading': 'Reading the models here…', 
           'requests': 'Requests', 'no_requests': 'Nothing asked yet.', 'stop': 'Stop', 'refresh': 'Refresh', 'st_pending': 'waiting', 'st_in_progress': 'working', 'st_done': 'done', 'st_blocked': "didn't finish", 'st_cancelled': 'stopped', 'st_awaiting_review': 'in review', 'by_model': 'by {model}', 'k_ask': 'a question', 'k_watch': 'a news watch', 'k_code': 'code', 'k_review': 'a review', 'k_read': 'reading', 'v_answered': 'answered', 'v_covered': 'covered', 'v_not_covered': 'not covered', 'k_request': 'a request', 'k_write': 'writing', 'k_delete': 'deleting', 'k_check': 'a check', 'k_look': 'a look', 'k_fetch': 'a fetch', 'v_changed': 'changed something', 'v_changed_nothing': 'changed nothing', 'v_checked': 'checked', 'v_declined': 'declined', 'v_stuck': 'got stuck', 'v_asks_the_person': 'asks you', 'v_looked': 'looked', 'v_fetched': 'fetched', 'v_not_given': 'not given', 'v_error': 'failed', 'v_not_done': 'not done', 'v_the_person_said_no': 'you said no', 
           "queued": 'Waiting its turn: the assistant is finishing another answer first ({ahead} ahead).', "allow": 'Allow', "no": 'No', "stick_read": 'Reading the assistant from the USB stick: {pct}%', "stick_wait": "Getting the assistant ready from the USB stick. The first time it reads the whole model from the stick, a few minutes; the header shows how far it is. Once it's installed, it starts in seconds.",
           "search_head": "Search the web for:", "search": "Search", "no_thanks": "No thanks", "looking": "Looking it up…",
           "search_note": "Only these words are sent, to {provider}. The pages it finds are read to answer you. "
                          "Nothing about you or this computer is sent.",
           "search_offline": "This computer is offline. Connect to the internet first; nothing is sent until you "
                             "click Search.",
           "watch_head": "Every day at {at}, look for news about:", "watch_head_only": "Every day at {at}, look on "
                                                                                   "{only} for news about:",
           "watch_empty": "(empty: the top stories)", "set_up": "Set up", "setting_up": "Setting it up…",
           "watch_note": "Every day these words are sent to {provider}, without asking again. Only what's new is "
                         "shown, each source in its own words. Nothing about you or this computer is sent. Pause or "
                         "delete it any time under Standing tasks.",
           "watch_offline": "This computer is offline. Connect to the internet first; nothing is set up until you "
                            "click Set up.",
           "standing": "Standing tasks", "pause": "Pause", "resume": "Resume", "delete": "Delete",
           "last_report": "Last report", "close": "Close",
           "standing_none": "Nothing yet. Ask for one in your own words, for example: “keep me up to date on Linux "
                            "Mint” or “the news about the weather every morning”.",
           "standing_head": "Your news watch on {what}: {n} new since last time.",
           "news_about": "News about “{topic}”", "top": "the top stories", "top_cap": "The top stories",
           "on_only": " on {only}", "every_day": "every day at {at}", "paused": " — paused",
           "not_run": "not run yet", "last_new": "last run {at}: {n} new", "last_trouble": "last run {at}: {trouble}",
           "line": "{what}, {when}.\n{said}",
           "key_head": "{name} needs a free key{use}. You register yourself; it takes a few minutes:",
           "key_use": " for {use}", "open_signup": "Open the sign-up page", "paste_key": "Paste the key here",
           "save_key": "Save the key", "later": "Later", "not_saved": "Not saved: {error}",
           "key_note": "The key goes straight into your login keyring, locked by your login password. The "
                       "assistant never sees it, and it isn't kept in the conversation. Only that source's own "
                       "requests use it.",
           "key_saved": "Key saved for {name}, in your login keyring. It's used from the next search on."},
    "es": {'h_helper': 'un archivo auxiliar, no un modelo', 'h_more': 'Más modelos', 'h_note': 'Tus palabras de búsqueda se envían a Hugging Face, y nada más.', 'h_search': 'Buscar', 'h_open': 'Descargar…', 'h_hint': 'p. ej. qwen coder', 'h_lic': 'licencia: {lic} (no revisada por nosotros)', 'h_no_lic': 'sin licencia indicada', 'h_dl': '{n} descargas', 'h_none': 'No se encontró nada.', 'h_check': '¿Funciona aquí?', 'h_checking': 'Comprobando…', 'h_parts': 'en partes: aún no se ofrece', 'h_mmproj': 'un lector de imágenes: no se ofrece por separado', 'h_nosum': 'sin suma de comprobación: no se ofrece', 'h_gated': 'pide iniciar sesión en Hugging Face: aún no se ofrece', 'h_no_job': 'Sin tarea por ahora', 'h_get': 'Descargar ({gb} GB)', 'h_drives': 'Buscar en unidades conectadas', 'h_no_drives': 'No hay modelos en las unidades conectadas.', 'h_bring': 'Traer ({gb} GB)', 'h_remove': 'Quitar', 'h_used': 'usado para {jobs}', 'h_runs_nothing': 'No funciona en este equipo.', 'h_room': 'No hay espacio suficiente: hacen falta {gb} GB.', 'h_have': 'Ya está en la carpeta de modelos.', 
           'models': 'Modelos', 'job_system': 'Ayuda y el sistema', 'job_coding': 'Escribir código (AICUI)', 'job_writing': 'Escritura', 'job_vision': 'Imágenes y vídeo', 'job_junior': 'Esbozar código', 'job_review': 'Revisión', 'job_research': 'Artículos de investigación', 'm_locked': 'Se queda con la guía: tiene las herramientas del sistema.', 'm_soon': 'Llegará cuando los modelos puedan pasarse el trabajo.', 'm_ours': 'nuestra elección', 'm_yours': 'tu elección', 'm_use_ours': 'Nuestra elección', 'm_fast': 'va bien aquí', 'm_slow': 'va lento aquí', 'm_no_fit': 'no funciona aquí', 'm_here': 'En este equipo', 'm_system': 'viene con el sistema', 'm_parked': 'guardado en {drive}', 'm_free': '{gb} GB libres para modelos', 'm_reading': 'Leyendo los modelos de este equipo…', 
           'requests': 'Peticiones', 'no_requests': 'Todavía no se ha pedido nada.', 'stop': 'Detener', 'refresh': 'Actualizar', 'st_pending': 'en espera', 'st_in_progress': 'en curso', 'st_done': 'hecho', 'st_blocked': 'no terminó', 'st_cancelled': 'detenido', 'st_awaiting_review': 'en revisión', 'by_model': 'por {model}', 'k_ask': 'una pregunta', 'k_watch': 'un seguimiento de noticias', 'k_code': 'código', 'k_review': 'una revisión', 'k_read': 'lectura', 'v_answered': 'respondido', 'v_covered': 'cubierto', 'v_not_covered': 'no cubierto', 'k_request': 'una petición', 'k_write': 'escribir', 'k_delete': 'borrar', 'k_check': 'una comprobación', 'k_look': 'una mirada', 'k_fetch': 'una descarga', 'v_changed': 'cambió algo', 'v_changed_nothing': 'no cambió nada', 'v_checked': 'comprobado', 'v_declined': 'rechazado', 'v_stuck': 'se atascó', 'v_asks_the_person': 'te pregunta', 'v_looked': 'miró', 'v_fetched': 'descargado', 'v_not_given': 'no asignado', 'v_error': 'falló', 'v_not_done': 'no hecho', 'v_the_person_said_no': 'dijiste que no', 
           "queued": 'Esperando su turno: el asistente está terminando otra respuesta ({ahead} por delante).', "allow": 'Permitir', "no": 'No', "stick_read": 'Leyendo el asistente desde la memoria USB: {pct}%', "stick_wait": 'Preparando el asistente desde la memoria USB. La primera vez lee todo el modelo de la memoria, unos minutos; arriba se ve cuánto lleva. Una vez instalado, arranca en segundos.',
           "search_head": "Buscar en la web:", "search": "Buscar", "no_thanks": "No, gracias", "looking": "Buscando…",
           "search_note": "Solo se envían estas palabras, a {provider}. Las páginas que encuentre se leen para "
                          "responderte. No se envía nada sobre ti ni sobre este equipo.",
           "search_offline": "Este equipo no tiene conexión. Conéctate a internet primero; no se envía nada hasta que "
                             "hagas clic en Buscar.",
           "watch_head": "Cada día a las {at}, buscar noticias sobre:",
           "watch_head_only": "Cada día a las {at}, buscar en {only} noticias sobre:",
           "watch_empty": "(vacío: las noticias principales)", "set_up": "Configurar", "setting_up": "Configurando…",
           "watch_note": "Cada día estas palabras se envían a {provider}, sin volver a preguntar. Solo se muestra lo "
                         "nuevo, cada fuente con sus propias palabras. No se envía nada sobre ti ni sobre este equipo. "
                         "Puedes pausarlo o eliminarlo cuando quieras en Tareas permanentes.",
           "watch_offline": "Este equipo no tiene conexión. Conéctate a internet primero; no se configura nada hasta "
                            "que hagas clic en Configurar.",
           "standing": "Tareas permanentes", "pause": "Pausar", "resume": "Reanudar", "delete": "Eliminar",
           "last_report": "Último informe", "close": "Cerrar",
           "standing_none": "Todavía no hay ninguna. Pídela con tus palabras, por ejemplo: «mantenme al día sobre "
                            "Linux Mint» o «las noticias sobre el tiempo cada mañana».",
           "standing_head": "Tu seguimiento de noticias sobre {what}: {n} novedades desde la última vez.",
           "news_about": "Noticias sobre «{topic}»", "top": "las noticias principales",
           "top_cap": "Las noticias principales", "on_only": " en {only}", "every_day": "cada día a las {at}",
           "paused": " — en pausa", "not_run": "todavía no se ha ejecutado", "last_new": "última vez {at}: {n} novedades",
           "last_trouble": "última vez {at}: {trouble}", "line": "{what}, {when}.\n{said}",
           "key_head": "{name} necesita una clave gratuita{use}. Te registras tú; lleva unos minutos:",
           "key_use": " para {use}", "open_signup": "Abrir la página de registro", "paste_key": "Pega la clave aquí",
           "save_key": "Guardar la clave", "later": "Más tarde", "not_saved": "No se guardó: {error}",
           "key_note": "La clave va directa a tu llavero de inicio de sesión, protegido con tu contraseña. El "
                       "asistente nunca la ve y no se guarda en la conversación. Solo la usan las consultas de esa "
                       "fuente.",
           "key_saved": "Clave guardada para {name} en tu llavero de inicio de sesión. Se usará a partir de la "
                        "próxima búsqueda."},
    "pt": {'h_helper': 'um arquivo auxiliar, não um modelo', 'h_more': 'Mais modelos', 'h_note': 'Suas palavras de busca vão para o Hugging Face, e nada mais.', 'h_search': 'Buscar', 'h_open': 'Baixar…', 'h_hint': 'ex.: qwen coder', 'h_lic': 'licença: {lic} (não revisada por nós)', 'h_no_lic': 'sem licença informada', 'h_dl': '{n} downloads', 'h_none': 'Nada encontrado.', 'h_check': 'Roda aqui?', 'h_checking': 'Verificando…', 'h_parts': 'em partes: ainda não oferecido', 'h_mmproj': 'um leitor de imagens: não oferecido sozinho', 'h_nosum': 'sem checksum: não oferecido', 'h_gated': 'pede login no Hugging Face: ainda não oferecido', 'h_no_job': 'Sem tarefa por enquanto', 'h_get': 'Baixar ({gb} GB)', 'h_drives': 'Procurar nas unidades conectadas', 'h_no_drives': 'Nenhum modelo nas unidades conectadas.', 'h_bring': 'Trazer ({gb} GB)', 'h_remove': 'Remover', 'h_used': 'usado para {jobs}', 'h_runs_nothing': 'Não roda neste computador.', 'h_room': 'Espaço insuficiente: são necessários {gb} GB.', 'h_have': 'Já está na pasta de modelos.', 
           'models': 'Modelos', 'job_system': 'Ajuda e o sistema', 'job_coding': 'Escrever código (AICUI)', 'job_writing': 'Escrita', 'job_vision': 'Imagens e vídeo', 'job_junior': 'Esboçar código', 'job_review': 'Revisão', 'job_research': 'Artigos de pesquisa', 'm_locked': 'Fica com o guia: ele tem as ferramentas do sistema.', 'm_soon': 'Chega quando os modelos puderem passar trabalho entre si.', 'm_ours': 'nossa escolha', 'm_yours': 'sua escolha', 'm_use_ours': 'Nossa escolha', 'm_fast': 'roda bem aqui', 'm_slow': 'roda devagar aqui', 'm_no_fit': 'não roda aqui', 'm_here': 'Neste computador', 'm_system': 'vem com o sistema', 'm_parked': 'guardado em {drive}', 'm_free': '{gb} GB livres para modelos', 'm_reading': 'Lendo os modelos deste computador…', 
           'requests': 'Pedidos', 'no_requests': 'Nada pedido ainda.', 'stop': 'Parar', 'refresh': 'Atualizar', 'st_pending': 'aguardando', 'st_in_progress': 'em andamento', 'st_done': 'feito', 'st_blocked': 'não terminou', 'st_cancelled': 'parado', 'st_awaiting_review': 'em revisão', 'by_model': 'por {model}', 'k_ask': 'uma pergunta', 'k_watch': 'um acompanhamento de notícias', 'k_code': 'código', 'k_review': 'uma revisão', 'k_read': 'leitura', 'v_answered': 'respondido', 'v_covered': 'coberto', 'v_not_covered': 'não coberto', 'k_request': 'um pedido', 'k_write': 'escrever', 'k_delete': 'apagar', 'k_check': 'uma verificação', 'k_look': 'uma olhada', 'k_fetch': 'um download', 'v_changed': 'mudou algo', 'v_changed_nothing': 'não mudou nada', 'v_checked': 'verificado', 'v_declined': 'recusado', 'v_stuck': 'travou', 'v_asks_the_person': 'pergunta a você', 'v_looked': 'olhou', 'v_fetched': 'baixado', 'v_not_given': 'não atribuído', 'v_error': 'falhou', 'v_not_done': 'não feito', 'v_the_person_said_no': 'você disse não', 
           "queued": 'Aguardando a vez: o assistente está terminando outra resposta ({ahead} na frente).', "allow": 'Permitir', "no": 'Não', "stick_read": 'Lendo o assistente do pendrive: {pct}%', "stick_wait": 'Preparando o assistente a partir do pendrive. Na primeira vez ele lê o modelo inteiro do pendrive, alguns minutos; o andamento aparece no topo. Depois de instalado, ele inicia em segundos.',
           "search_head": "Pesquisar na web:", "search": "Pesquisar", "no_thanks": "Não, obrigado",
           "looking": "Pesquisando…",
           "search_note": "Só estas palavras são enviadas, para {provider}. As páginas encontradas são lidas para "
                          "responder você. Nada sobre você ou este computador é enviado.",
           "search_offline": "Este computador está sem internet. Conecte-se primeiro; nada é enviado até você clicar "
                             "em Pesquisar.",
           "watch_head": "Todos os dias às {at}, procurar notícias sobre:",
           "watch_head_only": "Todos os dias às {at}, procurar no {only} notícias sobre:",
           "watch_empty": "(vazio: as principais notícias)", "set_up": "Configurar", "setting_up": "Configurando…",
           "watch_note": "Todos os dias estas palavras são enviadas para {provider}, sem perguntar de novo. Só aparece "
                         "o que é novo, cada fonte com as próprias palavras. Nada sobre você ou este computador é "
                         "enviado. Pause ou exclua quando quiser em Tarefas permanentes.",
           "watch_offline": "Este computador está sem internet. Conecte-se primeiro; nada é configurado até você "
                            "clicar em Configurar.",
           "standing": "Tarefas permanentes", "pause": "Pausar", "resume": "Retomar", "delete": "Excluir",
           "last_report": "Último relatório", "close": "Fechar",
           "standing_none": "Nenhuma ainda. Peça com suas palavras, por exemplo: “me mantenha atualizado sobre o "
                            "Linux Mint” ou “as notícias sobre o tempo todas as manhãs”.",
           "standing_head": "Seu acompanhamento de notícias sobre {what}: {n} novidades desde a última vez.",
           "news_about": "Notícias sobre “{topic}”", "top": "as principais notícias",
           "top_cap": "As principais notícias", "on_only": " no {only}", "every_day": "todos os dias às {at}",
           "paused": " — pausada", "not_run": "ainda não rodou", "last_new": "última vez {at}: {n} novidades",
           "last_trouble": "última vez {at}: {trouble}", "line": "{what}, {when}.\n{said}",
           "key_head": "{name} precisa de uma chave gratuita{use}. Você mesmo se cadastra; leva alguns minutos:",
           "key_use": " para {use}", "open_signup": "Abrir a página de cadastro", "paste_key": "Cole a chave aqui",
           "save_key": "Salvar a chave", "later": "Mais tarde", "not_saved": "Não foi salva: {error}",
           "key_note": "A chave vai direto para o seu chaveiro de sessão, protegido pela sua senha. O assistente "
                       "nunca a vê e ela não fica na conversa. Só as consultas dessa fonte a usam.",
           "key_saved": "Chave salva para {name} no seu chaveiro de sessão. Ela será usada a partir da próxima busca."},
    "fr": {'h_helper': "un fichier d'appoint, pas un modèle", 'h_more': 'Plus de modèles', 'h_note': "Vos mots de recherche sont envoyés à Hugging Face, rien d'autre.", 'h_search': 'Rechercher', 'h_open': 'Télécharger…', 'h_hint': 'p. ex. qwen coder', 'h_lic': 'licence : {lic} (non vérifiée par nous)', 'h_no_lic': 'aucune licence indiquée', 'h_dl': '{n} téléchargements', 'h_none': 'Rien trouvé.', 'h_check': 'Tourne-t-il ici ?', 'h_checking': 'Vérification…', 'h_parts': 'en plusieurs parties : pas encore proposé', 'h_mmproj': "un lecteur d'images : pas proposé seul", 'h_nosum': 'sans somme de contrôle : pas proposé', 'h_gated': 'demande une connexion à Hugging Face : pas encore proposé', 'h_no_job': "Pas de tâche pour l'instant", 'h_get': 'Télécharger ({gb} Go)', 'h_drives': 'Chercher sur les disques branchés', 'h_no_drives': 'Aucun modèle sur les disques branchés.', 'h_bring': 'Copier ici ({gb} Go)', 'h_remove': 'Retirer', 'h_used': 'utilisé pour {jobs}', 'h_runs_nothing': 'Il ne tourne pas sur cet ordinateur.', 'h_room': "Pas assez d'espace libre : {gb} Go nécessaires.", 'h_have': 'Déjà dans le dossier des modèles.', 
           'models': 'Modèles', 'job_system': 'Aide et système', 'job_coding': 'Écrire du code (AICUI)', 'job_writing': 'Écriture', 'job_vision': 'Images et vidéo', 'job_junior': 'Esquisser du code', 'job_review': 'Relecture', 'job_research': 'Articles de recherche', 'm_locked': 'Reste avec le guide : il détient les outils du système.', 'm_soon': 'Arrive quand les modèles pourront se passer le travail.', 'm_ours': 'notre choix', 'm_yours': 'votre choix', 'm_use_ours': 'Notre choix', 'm_fast': 'tourne bien ici', 'm_slow': 'tourne lentement ici', 'm_no_fit': 'ne tourne pas ici', 'm_here': 'Sur cet ordinateur', 'm_system': 'fourni avec le système', 'm_parked': 'rangé sur {drive}', 'm_free': '{gb} Go libres pour les modèles', 'm_reading': 'Lecture des modèles de cet ordinateur…', 
           'requests': 'Demandes', 'no_requests': "Rien de demandé pour l'instant.", 'stop': 'Arrêter', 'refresh': 'Actualiser', 'st_pending': 'en attente', 'st_in_progress': 'en cours', 'st_done': 'fait', 'st_blocked': 'pas terminé', 'st_cancelled': 'arrêté', 'st_awaiting_review': 'en relecture', 'by_model': 'par {model}', 'k_ask': 'une question', 'k_watch': "une veille d'actualités", 'k_code': 'du code', 'k_review': 'une relecture', 'k_read': 'lecture', 'v_answered': 'répondu', 'v_covered': 'couvert', 'v_not_covered': 'pas couvert', 'k_request': 'une demande', 'k_write': 'écrire', 'k_delete': 'supprimer', 'k_check': 'une vérification', 'k_look': "un coup d'œil", 'k_fetch': 'un téléchargement', 'v_changed': 'a changé quelque chose', 'v_changed_nothing': "n'a rien changé", 'v_checked': 'vérifié', 'v_declined': 'refusé', 'v_stuck': 'bloqué', 'v_asks_the_person': 'vous demande', 'v_looked': 'a regardé', 'v_fetched': 'téléchargé', 'v_not_given': 'non confié', 'v_error': 'échec', 'v_not_done': 'pas fait', 'v_the_person_said_no': 'vous avez dit non', 
           "queued": "En attente : l'assistant termine d'abord une autre réponse ({ahead} avant).", "allow": 'Autoriser', "no": 'Non', "stick_read": "Lecture de l'assistant depuis la clé USB : {pct} %", "stick_wait": "Préparation de l'assistant depuis la clé USB. La première fois, il lit tout le modèle sur la clé, quelques minutes ; l'en-tête montre l'avancement. Une fois installé, il démarre en quelques secondes.",
           "search_head": "Rechercher sur le web :", "search": "Rechercher", "no_thanks": "Non merci",
           "looking": "Recherche…",
           "search_note": "Seuls ces mots sont envoyés, à {provider}. Les pages trouvées sont lues pour vous "
                          "répondre. Rien sur vous ni sur cet ordinateur n'est envoyé.",
           "search_offline": "Cet ordinateur est hors ligne. Connectez-vous d'abord ; rien n'est envoyé avant que vous "
                             "cliquiez sur Rechercher.",
           "watch_head": "Chaque jour à {at}, chercher les nouvelles sur :",
           "watch_head_only": "Chaque jour à {at}, chercher sur {only} les nouvelles sur :",
           "watch_empty": "(vide : les principaux titres)", "set_up": "Configurer", "setting_up": "Configuration…",
           "watch_note": "Chaque jour, ces mots sont envoyés à {provider}, sans redemander. Seules les nouveautés sont "
                         "montrées, chaque source avec ses propres mots. Rien sur vous ni sur cet ordinateur n'est "
                         "envoyé. Suspendez-la ou supprimez-la quand vous voulez dans Tâches permanentes.",
           "watch_offline": "Cet ordinateur est hors ligne. Connectez-vous d'abord à internet ; rien n'est configuré "
                            "avant que vous cliquiez sur Configurer.",
           "standing": "Tâches permanentes", "pause": "Suspendre", "resume": "Reprendre", "delete": "Supprimer",
           "last_report": "Dernier rapport", "close": "Fermer",
           "standing_none": "Aucune pour l'instant. Demandez-la avec vos mots, par exemple : « tiens-moi au courant "
                            "de Linux Mint » ou « les nouvelles sur la météo chaque matin ».",
           "standing_head": "Votre veille d'actualités sur {what} : {n} nouveautés depuis la dernière fois.",
           "news_about": "Nouvelles sur « {topic} »", "top": "les principaux titres",
           "top_cap": "Les principaux titres", "on_only": " sur {only}", "every_day": "chaque jour à {at}",
           "paused": " — suspendue", "not_run": "pas encore lancée", "last_new": "dernière fois {at} : {n} nouveautés",
           "last_trouble": "dernière fois {at} : {trouble}", "line": "{what}, {when}.\n{said}",
           "key_head": "{name} demande une clé gratuite{use}. Vous vous inscrivez vous-même ; cela prend quelques "
                       "minutes :",
           "key_use": " pour {use}", "open_signup": "Ouvrir la page d'inscription", "paste_key": "Collez la clé ici",
           "save_key": "Enregistrer la clé", "later": "Plus tard", "not_saved": "Non enregistrée : {error}",
           "key_note": "La clé va directement dans votre trousseau de session, verrouillé par votre mot de passe. "
                       "L'assistant ne la voit jamais et elle n'est pas gardée dans la conversation. Seules les "
                       "requêtes de cette source l'utilisent.",
           "key_saved": "Clé enregistrée pour {name} dans votre trousseau de session. Elle servira dès la prochaine "
                        "recherche."},
    "de": {'h_helper': 'eine Hilfsdatei, kein Modell', 'h_more': 'Weitere Modelle', 'h_note': 'Deine Suchwörter gehen an Hugging Face, sonst nichts.', 'h_search': 'Suchen', 'h_open': 'Herunterladen …', 'h_hint': 'z. B. qwen coder', 'h_lic': 'Lizenz: {lic} (nicht von uns geprüft)', 'h_no_lic': 'keine Lizenz angegeben', 'h_dl': '{n} Downloads', 'h_none': 'Nichts gefunden.', 'h_check': 'Läuft es hier?', 'h_checking': 'Wird geprüft …', 'h_parts': 'in Teilen: noch nicht angeboten', 'h_mmproj': 'ein Bildleser: nicht einzeln angeboten', 'h_nosum': 'ohne Prüfsumme: nicht angeboten', 'h_gated': 'verlangt eine Anmeldung bei Hugging Face: noch nicht angeboten', 'h_no_job': 'Noch keine Aufgabe', 'h_get': 'Herunterladen ({gb} GB)', 'h_drives': 'Auf angeschlossenen Laufwerken suchen', 'h_no_drives': 'Keine Modelle auf angeschlossenen Laufwerken.', 'h_bring': 'Hierher kopieren ({gb} GB)', 'h_remove': 'Entfernen', 'h_used': 'genutzt für {jobs}', 'h_runs_nothing': 'Es läuft nicht auf diesem Computer.', 'h_room': 'Nicht genug Platz: {gb} GB nötig.', 'h_have': 'Schon im Modellordner.', 
           'models': 'Modelle', 'job_system': 'Hilfe und System', 'job_coding': 'Code schreiben (AICUI)', 'job_writing': 'Schreiben', 'job_vision': 'Bilder und Video', 'job_junior': 'Code entwerfen', 'job_review': 'Prüfen', 'job_research': 'Fachartikel', 'm_locked': 'Bleibt beim Guide: Er hat die Werkzeuge des Systems.', 'm_soon': 'Kommt, wenn Modelle einander Arbeit übergeben können.', 'm_ours': 'unsere Wahl', 'm_yours': 'deine Wahl', 'm_use_ours': 'Unsere Wahl', 'm_fast': 'läuft hier gut', 'm_slow': 'läuft hier langsam', 'm_no_fit': 'läuft hier nicht', 'm_here': 'Auf diesem Computer', 'm_system': 'gehört zum System', 'm_parked': 'ausgelagert auf {drive}', 'm_free': '{gb} GB frei für Modelle', 'm_reading': 'Die Modelle hier werden gelesen …', 
           'requests': 'Anfragen', 'no_requests': 'Noch nichts gefragt.', 'stop': 'Stoppen', 'refresh': 'Aktualisieren', 'st_pending': 'wartet', 'st_in_progress': 'läuft', 'st_done': 'fertig', 'st_blocked': 'nicht fertig geworden', 'st_cancelled': 'gestoppt', 'st_awaiting_review': 'in Prüfung', 'by_model': 'von {model}', 'k_ask': 'eine Frage', 'k_watch': 'eine Nachrichtenbeobachtung', 'k_code': 'Code', 'k_review': 'eine Prüfung', 'k_read': 'Lesen', 'v_answered': 'beantwortet', 'v_covered': 'abgedeckt', 'v_not_covered': 'nicht abgedeckt', 'k_request': 'eine Anfrage', 'k_write': 'Schreiben', 'k_delete': 'Löschen', 'k_check': 'eine Prüfung', 'k_look': 'ein Blick', 'k_fetch': 'ein Abruf', 'v_changed': 'hat etwas geändert', 'v_changed_nothing': 'hat nichts geändert', 'v_checked': 'geprüft', 'v_declined': 'abgelehnt', 'v_stuck': 'festgefahren', 'v_asks_the_person': 'fragt dich', 'v_looked': 'hat nachgesehen', 'v_fetched': 'abgerufen', 'v_not_given': 'nicht vergeben', 'v_error': 'fehlgeschlagen', 'v_not_done': 'nicht erledigt', 'v_the_person_said_no': 'du hast nein gesagt', 
           "queued": 'Wartet: Der Assistent beendet zuerst eine andere Antwort ({ahead} davor).', "allow": 'Erlauben', "no": 'Nein', "stick_read": 'Assistent wird vom USB-Stick gelesen: {pct} %', "stick_wait": 'Der Assistent wird vom USB-Stick vorbereitet. Beim ersten Mal liest er das ganze Modell vom Stick, ein paar Minuten; oben steht, wie weit er ist. Nach der Installation startet er in Sekunden.',
           "search_head": "Im Web suchen nach:", "search": "Suchen", "no_thanks": "Nein, danke", "looking": "Suche läuft…",
           "search_note": "Nur diese Wörter werden gesendet, an {provider}. Die gefundenen Seiten werden gelesen, um "
                          "Ihnen zu antworten. Nichts über Sie oder diesen Computer wird gesendet.",
           "search_offline": "Dieser Computer ist offline. Verbinden Sie sich zuerst; nichts wird gesendet, bevor Sie "
                             "auf Suchen klicken.",
           "watch_head": "Jeden Tag um {at} nach Neuigkeiten suchen zu:",
           "watch_head_only": "Jeden Tag um {at} auf {only} nach Neuigkeiten suchen zu:",
           "watch_empty": "(leer: die Top-Meldungen)", "set_up": "Einrichten", "setting_up": "Wird eingerichtet…",
           "watch_note": "Jeden Tag werden diese Wörter an {provider} gesendet, ohne erneut zu fragen. Gezeigt wird "
                         "nur Neues, jede Quelle mit ihren eigenen Worten. Nichts über Sie oder diesen Computer wird "
                         "gesendet. Pausieren oder löschen können Sie es jederzeit unter Daueraufgaben.",
           "watch_offline": "Dieser Computer ist offline. Verbinden Sie sich zuerst mit dem Internet; nichts wird "
                            "eingerichtet, bevor Sie auf Einrichten klicken.",
           "standing": "Daueraufgaben", "pause": "Pausieren", "resume": "Fortsetzen", "delete": "Löschen",
           "last_report": "Letzter Bericht", "close": "Schließen",
           "standing_none": "Noch keine. Bitten Sie mit Ihren Worten darum, zum Beispiel: „Halte mich auf dem "
                            "Laufenden über Linux Mint“ oder „die Nachrichten zum Wetter jeden Morgen“.",
           "standing_head": "Ihre Nachrichtenbeobachtung zu {what}: {n} neu seit dem letzten Mal.",
           "news_about": "Nachrichten zu „{topic}“", "top": "die Top-Meldungen", "top_cap": "Die Top-Meldungen",
           "on_only": " auf {only}", "every_day": "jeden Tag um {at}", "paused": " — pausiert",
           "not_run": "noch nicht gelaufen", "last_new": "zuletzt {at}: {n} neu", "last_trouble": "zuletzt {at}: {trouble}",
           "line": "{what}, {when}.\n{said}",
           "key_head": "{name} braucht einen kostenlosen Schlüssel{use}. Sie registrieren sich selbst; das dauert ein "
                       "paar Minuten:",
           "key_use": " für {use}", "open_signup": "Anmeldeseite öffnen", "paste_key": "Schlüssel hier einfügen",
           "save_key": "Schlüssel speichern", "later": "Später", "not_saved": "Nicht gespeichert: {error}",
           "key_note": "Der Schlüssel kommt direkt in Ihren Anmelde-Schlüsselbund, gesperrt mit Ihrem "
                       "Anmeldepasswort. Der Assistent sieht ihn nie, und er wird nicht im Gespräch gespeichert. Nur "
                       "die Anfragen dieser Quelle verwenden ihn.",
           "key_saved": "Schlüssel für {name} im Anmelde-Schlüsselbund gespeichert. Er wird ab der nächsten Suche "
                        "verwendet."},
    "ja": {'h_helper': '補助ファイルで、モデルではありません', 'h_more': 'ほかのモデル', 'h_note': '検索した言葉だけが Hugging Face に送られます。', 'h_search': '検索', 'h_open': 'ダウンロード…', 'h_hint': '例：qwen coder', 'h_lic': 'ライセンス：{lic}（私たちは確認していません）', 'h_no_lic': 'ライセンスの記載なし', 'h_dl': 'ダウンロード {n} 回', 'h_none': '見つかりませんでした。', 'h_check': 'ここで動きますか？', 'h_checking': '確認しています…', 'h_parts': '分割ファイル：まだ扱っていません', 'h_mmproj': '画像の読み取り部品：単体では扱いません', 'h_nosum': 'チェックサムなし：扱いません', 'h_gated': 'Hugging Face へのログインが必要：まだ扱っていません', 'h_no_job': 'まだ仕事なし', 'h_get': 'ダウンロード（{gb} GB）', 'h_drives': '接続したドライブを探す', 'h_no_drives': '接続したドライブにモデルはありません。', 'h_bring': '取り込む（{gb} GB）', 'h_remove': '削除', 'h_used': '{jobs} に使用中', 'h_runs_nothing': 'このコンピューターでは動きません。', 'h_room': '空き容量が足りません：{gb} GB 必要です。', 'h_have': 'すでにモデルフォルダーにあります。', 
           'models': 'モデル', 'job_system': 'ヘルプとシステム', 'job_coding': 'コードを書く（AICUI）', 'job_writing': '文章', 'job_vision': '画像と動画', 'job_junior': 'コードの骨組み', 'job_review': 'レビュー', 'job_research': '研究論文', 'm_locked': 'ガイドのままです。システムの道具を持っているからです。', 'm_soon': 'モデル同士が作業を受け渡せるようになったら使えます。', 'm_ours': 'おすすめ', 'm_yours': 'あなたの選択', 'm_use_ours': 'おすすめ', 'm_fast': 'ここで快適に動きます', 'm_slow': 'ここでは遅いです', 'm_no_fit': 'ここでは動きません', 'm_here': 'このコンピューターにあるもの', 'm_system': 'システムに付属', 'm_parked': '{drive} に保管中', 'm_free': 'モデル用の空き {gb} GB', 'm_reading': 'このコンピューターのモデルを読んでいます…', 
           'requests': 'リクエスト', 'no_requests': 'まだ何も頼まれていません。', 'stop': '停止', 'refresh': '更新', 'st_pending': '待機中', 'st_in_progress': '処理中', 'st_done': '完了', 'st_blocked': '完了せず', 'st_cancelled': '停止済み', 'st_awaiting_review': 'レビュー中', 'by_model': '担当：{model}', 'k_ask': '質問', 'k_watch': 'ニュースの見守り', 'k_code': 'コード', 'k_review': 'レビュー', 'k_read': '読み取り', 'v_answered': '回答済み', 'v_covered': '達成', 'v_not_covered': '未達成', 'k_request': 'リクエスト', 'k_write': '書き込み', 'k_delete': '削除', 'k_check': 'チェック', 'k_look': '確認（画面）', 'k_fetch': '取得', 'v_changed': '変更あり', 'v_changed_nothing': '変更なし', 'v_checked': 'チェック済み', 'v_declined': '辞退', 'v_stuck': '行き詰まり', 'v_asks_the_person': 'あなたへの質問', 'v_looked': '確認済み', 'v_fetched': '取得済み', 'v_not_given': '割り当てなし', 'v_error': '失敗', 'v_not_done': '未実行', 'v_the_person_said_no': 'あなたが拒否', 
           "queued": '順番待ち：アシスタントは先に別の回答を仕上げています（前に{ahead}件）。', "allow": '許可', "no": 'いいえ', "stick_read": 'USBメモリからアシスタントを読み込み中：{pct}%', "stick_wait": 'USBメモリからアシスタントを準備しています。初回はモデル全体をUSBメモリから読み込むため数分かかります。進み具合は上部に表示されます。インストール後は数秒で起動します。',
           "search_head": "ウェブで検索：", "search": "検索", "no_thanks": "結構です", "looking": "検索しています…",
           "search_note": "送られるのはこの言葉だけで、送り先は{provider}です。見つかったページを読んで答えます。あなたや"
                          "このコンピューターについての情報は送られません。",
           "search_offline": "このコンピューターはオフラインです。先に接続してください。「検索」を押すまで何も送られません。",
           "watch_head": "毎日{at}に、次の話題のニュースを探します：",
           "watch_head_only": "毎日{at}に、{only}で次の話題のニュースを探します：",
           "watch_empty": "（空欄：主なニュース）", "set_up": "設定する", "setting_up": "設定しています…",
           "watch_note": "毎日、この言葉が{provider}に送られます（毎回は確認しません）。新しいものだけを、各情報源の言葉の"
                         "まま表示します。あなたやこのコンピューターについての情報は送られません。定期タスクからいつでも"
                         "一時停止・削除できます。",
           "watch_offline": "このコンピューターはオフラインです。先にインターネットに接続してください。「設定する」を押すまで"
                            "何も設定されません。",
           "standing": "定期タスク", "pause": "一時停止", "resume": "再開", "delete": "削除",
           "last_report": "前回のレポート", "close": "閉じる",
           "standing_none": "まだありません。自分の言葉で頼んでください。例：「Linux Mintの最新情報を知らせて」"
                            "「毎朝、天気のニュースを教えて」。",
           "standing_head": "{what}のニュース見守り：前回から{n}件の新着です。",
           "news_about": "「{topic}」のニュース", "top": "主なニュース", "top_cap": "主なニュース",
           "on_only": "（{only}）", "every_day": "毎日{at}", "paused": "（一時停止中）", "not_run": "まだ実行されていません",
           "last_new": "前回 {at}：新着{n}件", "last_trouble": "前回 {at}：{trouble}", "line": "{what}、{when}。\n{said}",
           "key_head": "{name}には無料のキーが必要です{use}。登録はご自身で行います（数分で済みます）：",
           "key_use": "（{use}用）", "open_signup": "登録ページを開く", "paste_key": "ここにキーを貼り付け",
           "save_key": "キーを保存", "later": "あとで", "not_saved": "保存されませんでした：{error}",
           "key_note": "キーはログインパスワードで守られたログインキーリングに直接保存されます。アシスタントがキーを見ることは"
                       "なく、会話にも残りません。使うのはその情報源への問い合わせだけです。",
           "key_saved": "{name}のキーをログインキーリングに保存しました。次の検索から使われます。"},
}

# the search providers, as the daemon names them (websearch.PROVIDER, newsscan.PROVIDERS*), in each language
PROVIDERS = {
    "es": {"DuckDuckGo and Bing": "DuckDuckGo y Bing",
           "Google News and Bing News": "Google News y Bing News",
           "Google News, Bing (news and web), Reddit and Mastodon": "Google News, Bing (noticias y web), Reddit y Mastodon"},
    "pt": {"DuckDuckGo and Bing": "DuckDuckGo e Bing",
           "Google News and Bing News": "Google News e Bing News",
           "Google News, Bing (news and web), Reddit and Mastodon": "Google News, Bing (notícias e web), Reddit e Mastodon"},
    "fr": {"DuckDuckGo and Bing": "DuckDuckGo et Bing",
           "Google News and Bing News": "Google News et Bing News",
           "Google News, Bing (news and web), Reddit and Mastodon":
               "Google News, Bing (actualités et web), Reddit et Mastodon"},
    "de": {"DuckDuckGo and Bing": "DuckDuckGo und Bing",
           "Google News and Bing News": "Google News und Bing News",
           "Google News, Bing (news and web), Reddit and Mastodon":
               "Google News, Bing (Nachrichten und Web), Reddit und Mastodon"},
    "ja": {"DuckDuckGo and Bing": "DuckDuckGoとBing",
           "Google News and Bing News": "Google NewsとBing News",
           "Google News, Bing (news and web), Reddit and Mastodon": "Google News、Bing（ニュースとウェブ）、Reddit、Mastodon"},
}


def t(key: str, lang: str | None = None, **kw) -> str:
    table = T.get(lang or ui_lang(), T["en"])
    return table.get(key, T["en"][key]).format(**kw)


def provider(name: str, lang: str | None = None) -> str:
    return PROVIDERS.get(lang or ui_lang(), {}).get(name, name)


def search_note(offer: dict, lang: str | None = None) -> str:
    if not offer.get("online", True):
        return t("search_offline", lang)
    return t("search_note", lang, provider=provider(offer.get("provider", "DuckDuckGo"), lang))


def watch_note(offer: dict, lang: str | None = None) -> str:
    if not offer.get("online", True):
        return t("watch_offline", lang)
    return t("watch_note", lang, provider=provider(offer.get("provider", "the news sources"), lang))


def watch_head(offer: dict, lang: str | None = None) -> str:
    at = offer.get("at", "08:00")
    return t("watch_head_only", lang, at=at, only=offer["only"]) if offer.get("only") else t("watch_head", lang, at=at)


def standing_head(r: dict, lang: str | None = None) -> str:
    what = (f"“{r['topic']}”" if r.get("topic") else t("top", lang))
    return t("standing_head", lang, what=what, n=r.get("new", 0))


def standing_line(task: dict, lang: str | None = None) -> str:
    what = t("news_about", lang, topic=task["topic"]) if task.get("topic") else t("top_cap", lang)
    if task.get("only"):
        what += t("on_only", lang, only=task["only"])
    when = t("every_day", lang, at=task.get("at", "08:00")) + (t("paused", lang) if task.get("paused") else "")
    last = task.get("runs", [])[-1:] or [None]
    if last[0] is None:
        said = t("not_run", lang)
    elif last[0].get("trouble"):
        said = t("last_trouble", lang, at=last[0]["at"].replace("T", " "), trouble=last[0]["trouble"])
    else:
        said = t("last_new", lang, at=last[0]["at"].replace("T", " "), n=last[0].get("new", 0))
    return t("line", lang, what=what, when=when, said=said)


def key_head(card: dict, lang: str | None = None) -> str:
    use = t("key_use", lang, use=card["use"]) if card.get("use") else ""
    return t("key_head", lang, name=card.get("name", "This source"), use=use)


def key_saved(name: str, lang: str | None = None) -> str:
    return t("key_saved", lang, name=name)


def source_line(s: dict) -> str:
    import urllib.parse
    host = urllib.parse.urlsplit(s.get("url", "")).hostname or ""
    return f"[{s.get('n')}] {s.get('title', '')} — {host}"


# --- "Put in Writer" ------------------------------------------------------------------------------------

def worth_a_document(text: str) -> bool:
    """A real answer (a poem, steps, the PC's specs), not a one-liner or an offer the user still has to click."""
    t = text.strip()
    if len(t.split()) < 25:
        return False
    return not t.startswith(("I can look that up", "I'd need to look that up", "I've prepared this change"))


def document_title(first_line: str) -> str:
    t = first_line.strip().strip("#*:").strip()
    words_ = t.split()
    return " ".join(words_[:8]).rstrip(",.;:") if words_ else "From the assistant"


# --- the bigger model for an unusual terminal error (M3) ---------------------------------------------------------
def bigger_offer(offer: dict) -> str:
    return f"This error isn't in the built-in help. Ask {offer.get('model') or 'the bigger model'}?"


def bigger_note(offer: dict) -> str:
    return ("It's the larger model already on this computer. Loading it takes about a minute, and the assistant is "
            "back to normal with your next question. Nothing leaves this computer.")


def bigger_running(args: dict) -> str:
    return f"Loading {args.get('model') or 'the bigger model'}…"


def bigger_done(result: dict) -> str:
    return f"Answered by {result.get('model') or 'the bigger model'}; the assistant comes back with your next question"


def sent_to_terminal(reply: dict) -> str:
    """What happened after "To terminal" (M3)."""
    if reply.get("ok"):
        warn = "; ".join(reply.get("warnings") or [])
        return "It's at your prompt: check it, then press Enter in the terminal to run it." + (f" Careful: {warn}." if warn else "")
    return f"Not sent: {reply.get('error') or 'the terminal didn’t accept it'}."


# --- try it first (M3 slice 4) -------------------------------------------------------------------------------
TRYING = "Trying it on a copy of your folder…"


def can_try(command: str) -> bool:
    """Commands that change the system itself need the password, and the sandbox has no root: not offered."""
    return not re.match(r"\s*(sudo|pkexec|su)\b", command)


def trying(args: dict) -> str:
    return f"Trying in the sandbox: {args.get('command', '')}"


def try_verdict(r: dict) -> str:
    if not r.get("ok"):
        return f"Couldn't try it: {r.get('error', 'something went wrong')}"
    if r.get("timed_out"):
        return "It was still running after 3 minutes, so the try was stopped. Nothing in your folder changed."
    head = ("It worked on the copy." if r.get("exit") == 0 else
            f"It didn't work on the copy either (exit code {r.get('exit')}).")
    tail = " Your folder wasn't touched: to do it for real, use To terminal and press Enter there."
    if r.get("exit") == 0 and r.get("net") == "none":
        tail = " (The sandbox had no internet, because passt isn't installed.)" + tail
    return head + tail


def _names(part: dict) -> str:
    more = part["count"] - len(part["top"])
    return ", ".join(part["top"]) + (f" ({part['count']} files)" if part["count"] > len(part["top"]) or more else "")


def try_details(r: dict) -> list[tuple[str, bool]]:
    """(text, monospace) lines under the verdict: what it would make, change and delete, then its output."""
    if not r.get("ok"):
        return []
    out = []
    for key, verb in (("made", "It would create"), ("changed", "It would change"), ("deleted", "It would delete")):
        part = r.get(key) or {}
        if part.get("count"):
            out.append((f"{verb}: {_names(part)}", False))
    if r.get("venv"):
        out.append(("It ran with the terminal's active venv.", False))
    if r.get("output"):
        out.append((r["output"], True))
    return out


# --- terminal sharing (D77: offered, then on) -------------------------------------------------------------------
TERMINAL_OFFER = "Want me to see your terminals? Then I can read what went wrong instead of guessing."
TERMINAL_OFFER_NOTE = ("New terminals show ◆ in the prompt while I can see them; type ai off in one to make it "
                       "private. Password prompts are never captured, and nothing leaves this computer. You can turn "
                       "it off any time in the New… menu.")


def terminal_sharing_said(choice: str, state: dict) -> str:
    if state.get("error") or not state.get("available", True):
        return "Terminal sharing isn't available here (the cinminai-shell package isn't installed)."
    if choice == "on":
        return ("Done: new terminals are shared from now on (look for ◆). Terminals that are already open stay "
                "private; close and reopen one to share it.")
    if choice == "off":
        return "Terminal sharing is off: new terminals are private. Ones already open stay as they are until closed."
    if choice == "never":
        return "I won't ask again. You can still turn it on in the New… menu."
    return "No problem. I can ask another day, or you can turn it on in the New… menu."


# --- Explain on a command card (M3, SPEC §6.4) --------------------------------------------------------------------
def ui_lang() -> str:
    """The desktop's language, as one of the six (D25); English otherwise."""
    import os
    code = (os.environ.get("LANGUAGE") or os.environ.get("LC_ALL") or os.environ.get("LANG") or "en")[:2]
    return code if code in ("en", "es", "pt", "fr", "de", "ja") else "en"


def explain_question(command: str, lang: str = "en") -> str:
    """The question "Explain" sends, in the desktop's language: the command in backticks after it (the daemon
    recognises it and puts what the system knows about the command in front, cin_minai.daemon.commands)."""
    from cin_minai.daemon.commands import EXPLAIN
    return f"{EXPLAIN.get(lang, EXPLAIN['en'])}\n`{command}`"


# --- pictures (D64, D78) ------------------------------------------------------------------------------------------
PICTURE_TYPES = (".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".tif", ".tiff")
PICTURE_DEFAULT = "What's in this picture?"
LOOKING = "Looking at the picture… (loading the model that reads it can take a minute)"
VISION_NEEDS = "To do that I need a download first."
VIDEO_TYPES = (".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v", ".mpg", ".mpeg", ".wmv", ".flv", ".3gp", ".ts")
VIDEO_DEFAULT = "Summarize this video: tell me what I need to know."
WATCHING = "Watching the video… (this takes a few minutes: you can do other things meanwhile)"
NOT_A_PICTURE = "I can read pictures (photos, screenshots, scans) and watch videos. That file is neither."


def vision_setup(offer: dict) -> str:
    who = offer.get("model", "the model")
    size = offer.get("size_mb", "?")
    if offer.get("video"):
        parts = (["the picture reader (to see what's shown)"] if offer.get("reader") else []) + \
                (["the speech recognizer (to hear what's said)"] if offer.get("speech") else [])
        what = " and ".join(parts) or "one more file"
        line = (f"To watch videos I need {what}: {size} MB in all, downloaded once and checked when it arrives. "
                "Nothing leaves this computer when it watches.")
        if not offer.get("recommended"):
            line += " The built-in guide will read the pictures: it works, but the 27B coding model sees more."
        return line
    if offer.get("recommended"):
        return (f"{who} reads pictures best, and it needs its picture reader: one download, {size} MB, checked when "
                "it arrives. Nothing leaves this computer when it reads.")
    return (f"The built-in guide can read pictures with one download ({size} MB, checked when it arrives). It works, "
            "but its answers aren't as good as a bigger model's: for letters and forms the 27B coding model reads "
            "much better, if you have room for it.")


def vision_reading(args: dict) -> str:
    line = f"Reading the picture with {args.get('model', 'the model')} (it stays on this computer)…"
    if args.get("places"):
        line += f" {args['places']} places where those colours meet are looked at closely."
    return line


NUMBERS = re.compile(
    r"(?:\+?\d{1,3}[ .-]?)?\(?\d{3}\)?[ .-]?\d{3}[ .-]?\d{4}"            # phone numbers
    r"|[$€£¥]\s?\d[\d,.]*\d|\d[\d,.]*\d\s?(?:USD|EUR|dollars|euros)"    # amounts
    r"|\b\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}\b"                              # dates written with numbers
    r"|\b(?:account|acct|invoice|reference|ref)\b\.?\s*(?:no\b\.?|number|#)?\s*:?\s*(?=[A-Z-]*\d)[A-Z0-9-]{4,}", re.I)
# (2026-10-05: without the word ends and the digit, "refrigerator" was an account number: "ref" + "rigerator")


# a video's answer also: measurements and part/model numbers — the lab's video errors were a soldering station's model
# number and a file extension (2026-10-03); temperatures and torques are what a viewer acts on
MEASURES = re.compile(
    r"(?<![\w.,])\d+(?:[.,]\d+)?\s?(?:°\s?[CF]|degrees|Nm|newton[- ]metres?|newton[- ]meters?|ft[- ]?lbs?|psi|bar|"
    r"mm|cm|inch(?:es)?|V|volts?|amps?|A|W|watts?|ml|L|litres?|liters?|kg|g|lbs?|rpm|%)(?![\w°])"
    r"|(?<![\w-])(?=[A-Z0-9-]*\d)(?=[A-Z0-9-]*[A-Z])[A-Z0-9][A-Z0-9-]{4,}(?![\w-])")


def numbers_heard(answer: str) -> list[str]:
    """numbers_read plus measurements and part numbers, for a video's answer."""
    out = numbers_read(answer)
    for m in MEASURES.finditer(answer or ""):
        n = m.group(0).strip()
        if n not in out and not any(n in o for o in out):
            out.append(n)
    return out


def numbers_read(answer: str) -> list[str]:
    """Phone numbers, amounts, numeric dates and account numbers in a picture's answer, each once, in order. Said by
    us, not left to the model: on 2026-10-04 it read a letter's numbers three different ways across three readings,
    once "100% confident", and ignored the instruction to mark them."""
    seen, out = set(), []
    for m in NUMBERS.finditer(answer or ""):
        n = m.group(0).strip()
        if n not in seen:
            seen.add(n)
            out.append(n)
    return out


def vision_caveat(result: dict, answer: str = "") -> str:
    """D64: always said — the picture's quality decides the answer's; numbers read from it are named."""
    found = numbers_read(answer)
    base = ("Numbers read from the picture: " + ", ".join(found[:8]) + ". Check them against the original before "
            "you use them: small digits in a photo are easy to misread. " if found else "")
    base += "A clear, well-lit picture gives the best answer; check what matters against the original."
    if not result.get("recommended"):
        base += " Read by the built-in guide: it works, but a bigger model reads more reliably."
    if result.get("reduced"):
        base += f" It was slower this time: {result['reduced']}."
    return base


STAGES = {"speech": "listening to what's said", "frames": "picking the moments where the picture changes",
          "pictures": "getting YouTube's preview pictures", "summary": "writing the summary"}


def video_step(args: dict, more: dict) -> str:
    """One line that follows the job: listening, frame 4 of 23, writing."""
    stage = more.get("stage", "")
    if stage == "asking_firefox":
        return "Looking at the video open in Firefox…"
    if stage == "frame":
        doing = f"looking at moment {more.get('n')} of {more.get('of')} ({more.get('at')})"
    elif stage == "notes":  # a long video: notes part by part, then the summary
        doing = f"taking notes, part {more.get('n')} of {more.get('of')} (from {more.get('at')})"
    else:
        doing = STAGES.get(stage, "working")
        if stage == "speech" and more.get("length"):
            doing += f" (the video is {more['length']} long)"
    return f"Watching {args.get('file', 'the video')} with {args.get('model', 'the model')}: {doing}…"


def video_caveat(result: dict, answer: str = "") -> str:
    """D64/D65, said every time: what it went by, and that names and numbers need checking."""
    base = f"Watched in {result['took']}: " if result.get("took") else ""
    base += f"{result.get('frames', 0)} moments looked at"
    if result.get("source") == "youtube":  # YouTube's transcript and preview pictures: no ads in either
        base += (", with the video's transcript." if result.get("speech") else "; the video has no transcript.")
        base += " Ads aren't in the transcript or the pictures, so they're not in the summary."
    else:
        base += ", and what's said in it." if result.get("speech") else "; I heard no speech in it."
    found = numbers_heard(answer)
    if found:
        base += (" Numbers from the video: " + ", ".join(found[:8]) + ". Check them in the video before you rely "
                 "on them: speech recognition and small text both mishear and misread.")
    else:
        base += " Names and numbers can be misheard: check what matters in the video."
    if not result.get("recommended"):
        base += " Watched with the built-in guide: it works, but a bigger model sees more."
    if result.get("reduced"):
        base += f" It was slower this time: {result['reduced']}."
    return base


# --- answers as formatted text --------------------------------------------------------------------------------
# The models write Markdown; the sidebar showed it raw ("**[0:30]**", "* ") — worst in long video summaries
# (2026-10-04). Shown as Pango markup; the label keeps the raw text for the command cards, Writer and the caveats.
_BOLD = re.compile(r"\*\*(?=\S)(.+?)(?<=\S)\*\*|__(?=\S)(.+?)(?<=\S)__")
_ITALIC = re.compile(r"(?<![\w*])\*(?=[^\s*])(.+?)(?<=[^\s*])\*(?![\w*])")
_CODE = re.compile(r"`([^`\n]+)`")
_LINK = re.compile(r"\[([^\]\n]+)\]\((https?://[^)\s]+)\)")
_HEADING = re.compile(r"^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$")
_BULLET = re.compile(r"^(\s*)[-*+]\s+(.*)$")
_RULE = re.compile(r"^\s*([-*_])(\s*\1){2,}\s*$")


def _escape(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _inline(text: str) -> str:
    """One line of Markdown, escaped, with bold, italic, code and links; code is left alone inside."""
    parts = re.split(r"(`[^`\n]+`)", text)
    out = []
    for part in parts:
        if _CODE.fullmatch(part):
            out.append("<tt>" + _escape(part[1:-1]) + "</tt>")
            continue
        links = []

        def keep(m):
            links.append(f'<a href="{_escape(m.group(2))}">{_escape(m.group(1))}</a>')
            return f"\x00{len(links) - 1}\x00"
        part = _escape(_LINK.sub(keep, part))
        part = _BOLD.sub(lambda m: "<b>" + (m.group(1) or m.group(2)) + "</b>", part)
        part = _ITALIC.sub(r"<i>\1</i>", part)
        part = re.sub("\x00(\\d+)\x00", lambda m: links[int(m.group(1))], part)
        out.append(part)
    return "".join(out)


def markdown(text: str) -> str:
    """Pango markup for an answer written in Markdown: headings and **bold** in bold, *italic*, `code` and fenced
    blocks in a fixed-width font, bullets as •, links clickable. Anything else stays as written."""
    out, fenced = [], False
    for line in (text or "").split("\n"):
        if line.strip().startswith("```"):
            fenced = not fenced
            continue
        if fenced:
            out.append("<tt>" + _escape(line) + "</tt>")
            continue
        m = _HEADING.match(line)
        if m:
            out.append("<b>" + _inline(m.group(1).strip("*")) + "</b>")
            continue
        if _RULE.match(line):
            out.append("")
            continue
        m = _BULLET.match(line)
        if m:
            depth = len(m.group(1).replace("\t", "    ")) // 2
            out.append("  " * depth + "• " + _inline(m.group(2)))
            continue
        out.append(_inline(line))
    return "\n".join(out)



# --- M4: action cards (PLAN D85, SPEC §8.3) ----------------------------------------------------------------------
def action_lines(card: dict) -> list[tuple[str, str]]:
    """The waiting card's lines: what it wants to do, why, and what's special about it."""
    lines = [("The assistant wants to:", "what"), (card.get("summary", "do something"), "")]
    if card.get("reason"):
        lines.append((f"Why: {card['reason']}", "note"))
    if card.get("lane") == "admin":
        lines.append(("After Allow, your password is asked for — the assistant is not the administrator.", "note"))
    elif not card.get("reversible"):
        lines.append(("This can't be undone.", "note"))
    if card.get("destructive"):
        lines.append(("Back up first: this changes a disk or the system's start-up.", "note"))
    return lines


def action_done(card: dict) -> str:
    return f"Done: {card.get('summary', '')}"


def action_undone(ok: bool) -> str:
    return "Undone — it's back as it was." if ok else "It couldn't be put back fully; the record shows what's left."


def action_failed(card: dict) -> str:
    why = f" — {card['error']}" if card.get("error") else ""
    return f"That didn't work, so nothing was changed ({card.get('summary', '')}){why}."


def action_declined(card: dict) -> str:
    return f"Not done: the password wasn't given, so nothing was changed ({card.get('summary', '')})."


def action_error(message: str) -> str:
    """D-Bus errors arrive as 'GDBus.Error:org.cinminai…: the reason'; the person reads the reason."""
    return message.split(": ", 1)[-1] if ": " in message else message


def request_lines(task: dict, lang: str | None = None) -> tuple[str, str]:
    """(the line, the detail) for one task in the Requests view: its title and state; what kind it was and which
    model did it (SPEC §22.3: how a combination of models did, at a glance)."""
    state = t("st_" + task.get("status", "pending"), lang) if ("st_" + task.get("status", "")) in T["en"] \
        else task.get("status", "")
    kind = t("k_" + task["kind"], lang) if ("k_" + (task.get("kind") or "")) in T["en"] else (task.get("kind") or "")
    model = verdict = ""
    try:
        out = json.loads(task.get("result") or "")
        if isinstance(out, dict):
            model, verdict = str(out.get("model", "")), str(out.get("verdict", ""))
    except ValueError:
        pass
    key = "v_" + verdict.replace(" ", "_")  # how a task ended (cin_minai.engine): in the person's language
    verdict = t(key, lang) if verdict and key in T["en"] else verdict
    detail = " · ".join(x for x in (kind, t("by_model", lang, model=model) if model else "", verdict) if x)
    return f"{task.get('title', '')} — {state}", detail


def job_lines(job: dict, lang: str | None = None) -> tuple[str, str]:
    """(the job's name, what does it now) for the Models view (SPEC §22.3)."""
    name = t("job_" + job["job"], lang)
    if job.get("locked"):
        return name, f"{(job.get('current') or {}).get('model', '')} · {t('m_locked', lang)}"
    if not job.get("active"):
        return name, t("m_soon", lang)
    cur = job.get("current") or {}
    return name, f"{cur.get('model', '')} · {t('m_yours' if job.get('chosen') else 'm_ours', lang)}"


def choice_label(choice: dict, lang: str | None = None) -> str:
    speed = "m_no_fit" if not choice.get("fits") else "m_fast" if choice.get("tok_s", 0) >= 6 else "m_slow"
    return f"{choice['model']} — {t(speed, lang)}"


def licence_line(lic: str, lang: str | None = None) -> str:
    """The licence as the repository states it: never reviewed by us, and said so."""
    return t("h_lic", lang, lic=lic) if lic else t("h_no_lic", lang)


def fit_lines(fit: dict, lang: str | None = None) -> list[str]:
    """One line per job a model could do here: the job and how it runs."""
    return [f"{t('job_' + job, lang)}: "
            + t("m_no_fit" if not f["fits"] else "m_fast" if f.get("tok_s", 0) >= 6 else "m_slow", lang)
            for job, f in fit.items()]
