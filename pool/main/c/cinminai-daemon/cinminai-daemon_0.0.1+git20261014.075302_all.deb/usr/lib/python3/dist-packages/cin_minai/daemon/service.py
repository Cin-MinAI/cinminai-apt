# SPDX-License-Identifier: GPL-3.0-or-later
"""org.cinminai.Assistant1 on the session bus (SPEC §4, D15).

Compatible with the M0 spike's clients (applet, sidebar: Ask/Cancel/Reset, Token/Done/Error, State,
Model, Awareness); new: the Action signal (every tool the guide uses is shown, SPEC §5.5), the Status
property (model, where it runs, context, and why it's reduced, SPEC §4.2 "say so"), Load and Unload.
The model runs on worker threads; the bus never waits on it (GLib.idle_add hands results back).
"""

from __future__ import annotations

import datetime
import json
import os
import sys
import threading
import time

from gi.repository import Gio, GLib

from cin_minai.actions import admin, hook
from cin_minai.actions.core import ActionError, Actions
from cin_minai.inference.backend import BackendError, Cancelled, InferenceBackend

from .guide import Guide
from .office import LO, OfficeError
from .journal import Interviewer, Journal, JournalError
from . import config, manuscript, selfupdate, standing, websearch
from .say import quoted, say
from .models import Cancelled as DownloadStopped, ModelStore, backend_cfg, benchmark
from cin_minai.inference import matcher
from cin_minai.inference.llamacpp import LlamaCppBackend
from .projects import CIRCLE, ROOT as PROJECTS, Project
from .writer import Writer

NAME = "org.cinminai.Assistant1"
PATH = "/org/cinminai/Assistant1"
IFACE = "org.cinminai.Assistant1"
UPDATE_CHECK_S = 30            # D59: how often the daemon looks for an installed update
STANDING_CHECK_S = 60          # D88: how often standing tasks are checked for their time
IDLE_BEFORE_RESTART_S = 120    # and how long it must have been idle before restarting into it

XML = f"""
<node>
  <interface name="{IFACE}">
    <method name="Ask"><arg type="s" name="text" direction="in"/><arg type="u" name="id" direction="out"/></method>
    <method name="Cancel"/>
    <method name="Reset"/>
    <!-- D59: an installed update is waiting (Status update_ready): restart into it now, unless it's answering -->
    <method name="UpdateNow"/>
    <method name="Load"/>
    <method name="Unload"/>
    <!-- a proposed document edit (Action state "proposal", its result has the id): apply it, or discard it -->
    <method name="Decide"><arg type="s" name="proposal" direction="in"/><arg type="b" name="apply" direction="in"/>
      <arg type="s" name="json" direction="out"/></method>
    <!-- an offered web search (Action "web_search" state "proposal", its result has the id): the user clicked
         Search, with the query they saw (or edited). Nothing is sent before this call (D55, SPEC §7.5) -->
    <method name="Search"><arg type="s" name="offer" direction="in"/><arg type="s" name="query" direction="in"/>
      <arg type="u" name="id" direction="out"/></method>
    <!-- a terminal error no help card covers (Action "bigger_model" state "proposal", its result has the id): the
         person chose to ask the coding model they already have (Ian, 2026-10-04); it's loaded, answers, and is
         unloaded so the guide comes back -->
    <method name="AskBigger"><arg type="s" name="offer" direction="in"/><arg type="u" name="id" direction="out"/></method>
    <!-- "To terminal" on a command card (M3, SPEC §6.4): put the command at the prompt of the terminal the assistant
         last read, as if typed, without Enter. JSON out: ok, error, warnings (root, ssh) -->
    <method name="TerminalSend"><arg type="s" name="text" direction="in"/><arg type="s" name="json" direction="out"/></method>
    <!-- terminal sharing (D77: offered, then on): "on" / "off" (new terminals), "never" (don't offer again), "later",
         or "state"; JSON out: available (cinminai-shell installed), on, open (shared terminals now) -->
    <method name="TerminalSharing"><arg type="s" name="choice" direction="in"/><arg type="s" name="json" direction="out"/></method>
    <!-- "Try it first" on a command card (M3 slice 4): the command on a throwaway copy of the terminal's folder, in
         the sandbox; a job: Action "sandbox" running, then done with what happened (JSON). The folder isn't touched -->
    <method name="TerminalTry"><arg type="s" name="text" direction="in"/><arg type="u" name="id" direction="out"/></method>
    <!-- reading a picture or watching a video (D64, D78): the file's path and the person's request; a job. A video
         reports its steps as Action "video" running (JSON: stage speech/frames/frame/summary) and a summary. If the reading model's projector
         isn't here yet: Action "vision_setup" state "proposal" (JSON: id, model, size_mb, recommended) and nothing
         more; VisionSetup fetches it (Action "download" progress), then reads the picture -->
    <method name="AskImage"><arg type="s" name="path" direction="in"/><arg type="s" name="request" direction="in"/>
      <arg type="u" name="id" direction="out"/></method>
    <method name="VisionSetup"><arg type="s" name="offer" direction="in"/><arg type="u" name="id" direction="out"/></method>
    <!-- "Put in Writer": a new Writer document in Documents with this text (an answer), opened; never overwrites -->
    <method name="MakeDocument"><arg type="s" name="title" direction="in"/><arg type="s" name="text" direction="in"/>
      <arg type="s" name="json" direction="out"/></method>
    <!-- stop using the shared LibreOffice document (sharing itself is switched in LibreOffice's menu) -->
    <method name="ForgetDocument"/>
    <!-- writing projects (D54): while one is open, Ask goes to the writing partner, which gathers ideas as notes -->
    <method name="ProjectNew"><arg type="s" name="title" direction="in"/><arg type="s" name="json" direction="out"/></method>
    <method name="ProjectOpen"><arg type="s" name="folder" direction="in"/><arg type="s" name="json" direction="out"/></method>
    <method name="ProjectClose"/>
    <method name="ProjectList"><arg type="s" name="json" direction="out"/></method>
    <method name="ProjectInfo"><arg type="s" name="json" direction="out"/></method>
    <!-- the story's shape (D56), as JSON: shape ("chapter" or "chapters"), chapters (2-8), next_chapter; any of them -->
    <method name="ProjectSet"><arg type="s" name="settings" direction="in"/><arg type="s" name="json" direction="out"/></method>
    <!-- a bigger model for a task (D60): what the matcher would offer here (JSON); fetch it (a job: Action
         "download" running with progress, then done with the measured speed); use one or go back to the guide
         (file ""); never ask again about a file -->
    <method name="ModelOffer"><arg type="s" name="task" direction="in"/><arg type="s" name="json" direction="out"/></method>
    <method name="ModelDownload"><arg type="s" name="task" direction="in"/><arg type="u" name="id" direction="out"/></method>
    <method name="ModelUse"><arg type="s" name="task" direction="in"/><arg type="s" name="file" direction="in"/>
      <arg type="s" name="json" direction="out"/></method>
    <method name="ModelDecline"><arg type="s" name="file" direction="in"/></method>
    <!-- the finished story as a manuscript (D58), JSON in: author, contact; out: the .odt and .docx made -->
    <method name="MakeManuscript"><arg type="s" name="options" direction="in"/><arg type="s" name="json" direction="out"/></method>
    <!-- "Write it up" (D57): review the story as it is now before the next chapter: an Action "review" with state
         "proposal" (where the story is on the circle, characters, what's missing, questions) -->
    <method name="WriteUp"><arg type="s" name="wish" direction="in"/><arg type="u" name="id" direction="out"/></method>
    <!-- plan the chapter after the review: an Action "outline" with state "proposal" (its result has the id);
         answers: the writer's answers to the review and what should change (they become notes), as text, or
         JSON with "answers" and "written" (the steps the writer ticked: they decide where the chapter starts) -->
    <method name="PlanChapter"><arg type="s" name="answers" direction="in"/><arg type="u" name="id" direction="out"/></method>
    <!-- write the planned chapter: Action "draft" running (progress) then done (the file); Cancel stops it -->
    <method name="WriteDraft"><arg type="s" name="outline" direction="in"/><arg type="u" name="id" direction="out"/></method>
    <!-- the journal (D55): while it's open, Ask goes to the interviewer; today's conversation stays in memory -->
    <method name="JournalOpen"><arg type="s" name="json" direction="out"/></method>
    <method name="JournalClose"/>
    <method name="JournalEntries"><arg type="s" name="json" direction="out"/></method>
    <method name="JournalSetPin"><arg type="s" name="pin" direction="in"/><arg type="s" name="old" direction="in"/></method>
    <method name="JournalRead"><arg type="s" name="file" direction="in"/><arg type="s" name="pin" direction="in"/>
      <arg type="s" name="json" direction="out"/></method>
    <!-- write today's entry from the conversation: Action "journal" done (the entry) -->
    <method name="JournalWrite"><arg type="b" name="private" direction="in"/><arg type="u" name="id" direction="out"/></method>
    <!-- M4 (PLAN D85, SPEC §8): actions the assistant proposes. The card is drawn from the record, never from model text.
         ActionCard (JSON): id, event (waiting|done|failed|denied|undone), kind, lane, reversible, summary, reason -->
    <method name="ActionAnswer"><arg type="s" name="id" direction="in"/><arg type="b" name="allow" direction="in"/>
      <arg type="s" name="json" direction="out"/></method>
    <method name="ActionUndo"><arg type="s" name="id" direction="in"/><arg type="b" name="ok" direction="out"/></method>
    <method name="ActionList"><arg type="s" name="json" direction="out"/></method>
    <signal name="ActionCard"><arg type="s" name="json"/></signal>
    <!-- D88 standing tasks: set up from a "watch" proposal card (offer id, the topic as edited), listed, paused or
         deleted. Standing (JSON): a scheduled run's report with only what's new (id, topic, report, sources) -->
    <method name="StandingAdd"><arg type="s" name="offer" direction="in"/><arg type="s" name="topic" direction="in"/>
      <arg type="u" name="id" direction="out"/></method>
    <method name="StandingList"><arg type="s" name="json" direction="out"/></method>
    <method name="StandingChange"><arg type="s" name="task" direction="in"/><arg type="s" name="what" direction="in"/>
      <arg type="s" name="json" direction="out"/></method>
    <signal name="Standing"><arg type="s" name="json"/></signal>
    <!-- turn tokens (SPEC §22.4): the recent requests, each with its tree of tasks (JSON) -->
    <method name="TurnList"><arg type="s" name="json" direction="out"/></method>
    <!-- Stop a request (or any task in it): it and everything under it; a waiting one never starts -->
    <method name="TurnCancel"><arg type="u" name="task" direction="in"/><arg type="s" name="json" direction="out"/>
    </method>
    <!-- the Models view (SPEC §22.3): each job with its model and the models that can do it here; the models here -->
    <method name="ModelsView"><arg type="s" name="json" direction="out"/></method>
    <!-- give a job a model on this computer ("" = our pick again); help and the system stay with the guide (D94) -->
    <method name="ModelAssign"><arg type="s" name="job" direction="in"/><arg type="s" name="file" direction="in"/>
      <arg type="s" name="json" direction="out"/></method>
    <!-- more models from Hugging Face (hub.py): the search words go there, nothing else (D86) -->
    <method name="HubSearch"><arg type="s" name="query" direction="in"/><arg type="s" name="json" direction="out"/>
    </method>
    <method name="HubFiles"><arg type="s" name="repo" direction="in"/><arg type="s" name="json" direction="out"/>
    </method>
    <!-- whether a file there runs here, from its first megabytes: the jobs it can do and how fast -->
    <method name="HubCheck"><arg type="s" name="repo" direction="in"/><arg type="s" name="path" direction="in"/>
      <arg type="s" name="json" direction="out"/></method>
    <!-- fetch a checked file (resumes, checked against its checksum), test its speed, give it the job ("" = none) -->
    <method name="HubDownload"><arg type="s" name="file" direction="in"/><arg type="s" name="job" direction="in"/>
      <arg type="u" name="id" direction="out"/></method>
    <!-- models on connected drives, each with the jobs it can do here; bring one in (copied into the model folder) -->
    <method name="ModelRemove"><arg type="s" name="file" direction="in"/><arg type="s" name="json" direction="out"/>
    </method>
    <method name="ModelsOnDrives"><arg type="s" name="json" direction="out"/></method>
    <method name="ModelBringIn"><arg type="s" name="path" direction="in"/><arg type="s" name="job" direction="in"/>
      <arg type="u" name="id" direction="out"/></method>
    <!-- keys for sources that need one (keys.py): the key goes to the login keyring and nowhere else; the answer
         never repeats it. json: ok and the source's name, or ok false and the error -->
    <method name="KeySet"><arg type="s" name="source" direction="in"/><arg type="s" name="key" direction="in"/>
      <arg type="s" name="json" direction="out"/></method>
    <method name="KeyForget"><arg type="s" name="source" direction="in"/><arg type="s" name="json" direction="out"/></method>
    <!-- ask | auto (auto: reversible actions run on their own; irreversible and admin actions always ask) -->
    <property name="ActionMode" type="s" access="readwrite"/>
    <signal name="Token"><arg type="u" name="id"/><arg type="s" name="text"/></signal>
    <!-- replaces a reply already streamed when the generation loop detector trims it -->
    <signal name="Replace"><arg type="u" name="id"/><arg type="s" name="text"/></signal>
    <!-- a tool the guide used: state running | done; result is the tool's output (JSON or help text) -->
    <signal name="Action"><arg type="u" name="id"/><arg type="s" name="tool"/><arg type="s" name="args"/>
      <arg type="s" name="state"/><arg type="s" name="result"/></signal>
    <signal name="Done"><arg type="u" name="id"/></signal>
    <signal name="Error"><arg type="u" name="id"/><arg type="s" name="message"/></signal>
    <!-- idle | loading | thinking | off | error -->
    <property name="State" type="s" access="read"/>
    <!-- one line for the applet and the sidebar header -->
    <property name="Model" type="s" access="read"/>
    <!-- model, build (cuda|vulkan|cpu), context, reduced (why, in words; "" = full), detail, backend_state,
         document (the shared LibreOffice document the assistant sees; "" = none),
         project (the open writing project's title; "" = none), journal (b: the journal is open) -->
    <property name="Status" type="a{{sv}}" access="read"/>
    <property name="Awareness" type="a{{sb}}" access="readwrite"/>
    <property name="LastStats" type="s" access="read"/>
  </interface>
</node>
"""


def _out_args() -> dict:
    """Which methods are declared to answer (from the interface itself)."""
    iface = Gio.DBusNodeInfo.new_for_xml(XML).interfaces[0]
    return {m.name: bool(m.out_args) for m in iface.methods}


OUT_ARGS = _out_args()

WHERE = {"cuda": "graphics card", "vulkan": "graphics card", "cpu": "processor"}


WEB_VIDEO = "firefox:current-video"  # a setup offer made for the video open in Firefox


def log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def _mode_file() -> str:
    return os.path.join(os.path.dirname(config.user_config()), "actions-mode")


def actions_mode() -> str:
    """The person's choice (PLAN D85), kept beside their settings; the packaged default is ask."""
    try:
        with open(_mode_file(), encoding="utf-8") as f:
            mode = f.read().strip()
        if mode in ("ask", "auto"):
            return mode
    except OSError:
        pass
    return config.load()["actions"]["mode"]


def save_actions_mode(mode: str) -> None:
    os.makedirs(os.path.dirname(_mode_file()), exist_ok=True)
    with open(_mode_file(), "w", encoding="utf-8") as f:
        f.write(mode + "\n")


class Service:
    def __init__(self, loop: GLib.MainLoop, backend: InferenceBackend, guide: Guide, preload: bool) -> None:
        self.loop, self.backend, self.guide = loop, backend, guide
        if hasattr(backend, "on_progress"):  # the live stick's straight read, as a percentage in the header
            backend.on_progress = lambda: GLib.idle_add(self.changed, "Status")
        self.conn: Gio.DBusConnection | None = None
        self.state = "off"
        self.awareness = {"terminals": False, "browser": False, "web": False}  # nothing is watched in the Alpha
        self.last_stats = "{}"
        self.next_id = 0
        self.busy = False       # answering (one question at a time)
        self.loading = False    # a load started by Load or the preload; questions wait for it
        self.cancel = threading.Event()
        self.preload = preload
        self.document = ""  # title of the shared LibreOffice document, for the sidebar header (§7.6)
        self.project: Project | None = None  # the open writing project (D54)
        # D60: writing may use a bigger model the user chose; the card holds one model at a time
        self.store = ModelStore()
        self.writing_backend: tuple[str, LlamaCppBackend] | None = None
        self.vision_offers: dict[str, tuple[str, str]] = {}  # "set up reading pictures?": id -> (path, request)
        self.bigger_offers: dict[str, str] = {}  # offered "ask the bigger model", by id: the question with its terminal
        self.chain_offers: dict[str, dict] = {}  # D91: a chain waiting for its Search click, by offer id
        self.hub_found: dict = {}  # repo -> its files as Hugging Face listed them (the checksums come from here)
        self.hub_checked: dict = {}  # file -> the matcher's entry, read from its header: only these are fetched
        self.offers: dict = {}  # task -> (time, the matcher's plan), so the machine isn't read on every open
        self.writer = Writer(self.writing_chat)
        self.outlines: dict[str, dict] = {}
        self.journal: Journal | None = None  # the open journal (D55)
        self.interviewer = Interviewer(backend.chat)
        # D59: after an update, restart into the new version when idle; reopen the project that was open
        self.watcher = selfupdate.Watcher()
        self.active_at = time.monotonic()
        self.update_ready = False  # shown in the sidebar with "Restart now" while it waits for a pause
        self.just_updated = selfupdate.take_updated()  # this start is the new version: the sidebar says so once
        if self.just_updated:
            GLib.timeout_add_seconds(600, self.forget_updated)
        reopen = selfupdate.take_reopen()
        if reopen:
            try:
                self.project = Project.open(reopen)
                log(f"updated: reopened the writing project {self.project.title!r}")
            except (OSError, ValueError):
                pass
        GLib.timeout_add_seconds(UPDATE_CHECK_S, self.check_update)
        # D88: standing tasks, checked every minute; a run never overlaps a question or another run
        self.standing = standing.Store()
        self.watch_offers: dict[str, dict] = {}  # "keep me up to date on X" cards waiting for their click
        self.standing_running = False
        self.cuda_asked = False  # D93: the CUDA engine is offered at most once per run (and never again after "No")
        # turn tokens (SPEC §22.4): every request is a task on the computer's own Team Table; a request that comes
        # while the assistant is answering waits its turn instead of being refused
        from . import turns
        self.turns = turns.open_table(int(getattr(backend, "cfg", {}).get("context", 8192) or 8192))
        self.waiting: dict[int, tuple[int, str]] = {}  # task id -> (request id, text)
        self.rid_task: dict[int, int] = {}            # request id -> its task
        self.turn_ctx = 0
        if self.turns is not None:
            self.turns.close_stale()
        GLib.timeout_add_seconds(STANDING_CHECK_S, self.standing_tick)
        # M4: one path for every action (PLAN D67, D85)
        self.actions = Actions(mode=actions_mode(), notify=self.action_notify)
        admin.register(self.actions)     # the root mechanism's verbs; each asks, then polkit asks for the password
        hook.install(self.actions)

    def check_update(self) -> bool:
        """D59: restart into an installed update once it's complete, loads, and the daemon has been idle a while.
        Never while answering or loading, never with the journal open (its conversation lives only in memory)."""
        state = self.watcher.check()
        waiting = state == "ready" and self.watcher.refused != self.watcher.seen
        if waiting != self.update_ready:
            self.update_ready = waiting
            self.changed("Status")
        if not waiting or self.busy or self.loading or self.journal is not None or self.standing_running:
            return True
        if time.monotonic() - self.active_at < IDLE_BEFORE_RESTART_S:
            return True
        return self.restart_for_update()

    def forget_updated(self) -> bool:
        self.just_updated = False
        self.changed("Status")
        return False

    def restart_for_update(self) -> bool:
        """Test-load the installed code, then restart into it (the daemon exits; systemd starts the new version). If it
        doesn't load, the running version stays and says why, once per version."""
        ok, why = selfupdate.loads()
        if not ok:
            self.watcher.refused = self.watcher.seen
            self.update_ready = False
            self.changed("Status")
            log(f"an update is installed but it doesn't load, so the running version stays: {why}")
            return True
        log("an update is installed: restarting into the new version")
        self.backend.unload()
        selfupdate.restart(self.project.folder if self.project else None)
        return False

    # --- bus plumbing ------------------------------------------------------------------------------
    def acquired(self, conn: Gio.DBusConnection, name: str) -> None:
        self.conn = conn
        conn.register_object(PATH, Gio.DBusNodeInfo.new_for_xml(XML).interfaces[0], self.call, self.get, self.set)
        log(f"owning {NAME}")
        # LibreOffice says when a document is shared or not (its menu); the header follows
        conn.signal_subscribe(LO[0], LO[2], "Shared", LO[1], None, Gio.DBusSignalFlags.NONE,
                              lambda *a: self.refresh_document(), None)
        conn.signal_subscribe("org.freedesktop.DBus", "org.freedesktop.DBus", "NameOwnerChanged",
                              "/org/freedesktop/DBus", LO[0], Gio.DBusSignalFlags.NONE,
                              lambda *a: self.refresh_document(), None)
        self.refresh_document()
        if self.preload:
            self.start_load()

    def lost(self, conn, name) -> None:
        log(f"lost {name} (is another daemon running?)")
        self.loop.quit()

    def model_line(self) -> str:
        st = self.backend.status()
        if st.state in ("ready", "loading") and st.build:
            line = f"{st.model} · {st.context // 1024}K · {WHERE.get(st.build, st.build)}"
            return line + (f" — {st.reduced}" if st.reduced else "")
        if st.state == "error":
            return f"{st.model} — not available"
        return st.model

    def variant(self, prop: str) -> GLib.Variant:
        st = self.backend.status()
        return {
            "State": lambda: GLib.Variant("s", self.state),
            "Model": lambda: GLib.Variant("s", self.model_line()),
            "Status": lambda: GLib.Variant("a{sv}", {
                "model": GLib.Variant("s", st.model), "build": GLib.Variant("s", st.build),
                "context": GLib.Variant("u", st.context), "reduced": GLib.Variant("s", st.reduced),
                "detail": GLib.Variant("s", st.detail), "backend_state": GLib.Variant("s", st.state),
                "document": GLib.Variant("s", self.document),
                "project": GLib.Variant("s", self.project.title if self.project else ""),
                "journal": GLib.Variant("b", self.journal is not None),
                "update_ready": GLib.Variant("b", self.update_ready),
                "just_updated": GLib.Variant("b", self.just_updated)}),
            "Awareness": lambda: GLib.Variant("a{sb}", self.awareness),
            "LastStats": lambda: GLib.Variant("s", self.last_stats),
            "ActionMode": lambda: GLib.Variant("s", self.actions.mode),
        }[prop]()

    def changed(self, *props: str) -> None:
        if self.conn:
            self.conn.emit_signal(None, PATH, "org.freedesktop.DBus.Properties", "PropertiesChanged",
                                  GLib.Variant("(sa{sv}as)", (IFACE, {p: self.variant(p) for p in props}, [])))

    def emit(self, signal: str, fmt: str, *args) -> bool:
        if self.conn:
            self.conn.emit_signal(None, PATH, IFACE, signal, GLib.Variant(fmt, args))
        return False

    def get(self, conn, sender, path, iface, prop):
        return self.variant(prop)

    def set(self, conn, sender, path, iface, prop, value) -> bool:
        if prop == "ActionMode":
            mode = value.unpack()
            if mode not in ("ask", "auto"):
                return False
            if mode != self.actions.mode:      # a boundary change: the person's, and recorded
                self.actions.record.add("mode", mode=mode, by="person")
                self.actions.mode = mode
                save_actions_mode(mode)
                self.changed("ActionMode")
            return True
        if prop == "Awareness":
            self.awareness.update(value.unpack())
            self.changed("Awareness")
            return True
        return False

    @staticmethod
    def card(p, event: str) -> dict:
        """What the sidebar shows: from the daemon's own record of the action, never from model text alone."""
        return {"id": p.id, "event": event, "kind": p.kind.name, "lane": p.kind.lane,
                "reversible": p.kind.reversible, "destructive": p.kind.destructive,
                "summary": p.kind.summary(p.args), "reason": p.reason, "undo": bool(p.undo),
                "error": str(p.error)[:300] if p.error and event in ("failed", "denied") else "",
                "at": "password" if event == "denied" and p.error else ""}

    def action_notify(self, event: str, p) -> None:
        GLib.idle_add(self.emit, "ActionCard", "(s)", json.dumps(self.card(p, event), ensure_ascii=False))
        from . import installs
        if p.kind.name == "admin.install_package" and p.args.get("package") == installs.CUDA_PKG:
            if event == "denied" and p.error is None:  # "No" on the card (a cancelled password may be an accident)
                installs.decline("cuda")
            elif event == "done":  # onto CUDA at the next pause
                GLib.timeout_add_seconds(5, self.reload_for_cuda)

    def maybe_step_up(self) -> None:
        """Back onto the graphics card once it has room again (checked every minute while the assistant is idle on
        the processor because the card was busy). A question asked meanwhile is never interrupted."""
        has_room = getattr(self.backend, "card_has_room", None)
        if has_room is None or self.busy or self.loading or self.backend.status().state != "ready":
            return
        if has_room():
            log("the graphics card has room again: moving the assistant back onto it")
            self.backend.unload()
            self.start_load()

    def reload_for_cuda(self) -> bool:
        if self.busy or self.loading:
            return True  # after this answer
        self.backend.unload()
        self.start_load()
        return False

    def maybe_offer_cuda(self) -> None:
        """D93: once the NVIDIA driver is in and the CUDA engine isn't, offer it on one card, with its size."""
        from . import installs
        if self.cuda_asked or self.backend.status().state != "ready":
            return
        self.cuda_asked = True
        server_dir = getattr(self.backend, "server_dir", "")
        if not server_dir or "admin.install_package" not in self.actions.kinds or installs.declined("cuda"):
            return
        lang = self.guide.tools.lang

        def work():
            if not installs.cuda_wanted(server_dir) or installs.state(installs.CUDA_PKG) != "available":
                return
            mb = installs.download_mb(installs.CUDA_PKG)
            size = say(lang, "size_mb", mb=mb) if mb else say(lang, "size_unknown")
            self.actions.propose("admin.install_package", {"package": installs.CUDA_PKG},
                                 reason=say(lang, "cuda_reason", size=size))
        threading.Thread(target=work, daemon=True).start()

    def offer_driver(self, on_text, on_action) -> dict:
        """The driver the system's own tool recommends (Driver Manager's list), proposed on the Allow card."""
        from . import installs
        lang = self.guide.tools.lang
        pkg = installs.recommended_driver()
        if not pkg:
            on_text(say(lang, "driver_none"))
            return {"tool": "driver", "recommended": ""}
        if installs.state(pkg) == "installed":
            on_text(say(lang, "driver_have", pkg=pkg))
            return {"tool": "driver", "recommended": pkg, "installed": True}
        self.actions.propose("admin.install_package", {"package": pkg}, reason=say(lang, "driver_reason"))
        from cin_minai.sidebar.words import t
        on_text(say(lang, "driver_offer", pkg=pkg, allow=t("allow", lang)))
        return {"tool": "driver", "recommended": pkg, "proposed": True}

    def set_state(self, state: str) -> bool:
        if state != self.state:
            self.state = state
            self.changed("State", "Model", "Status")
        return False

    def call(self, conn, sender, path, iface, method, params, inv) -> None:
        self.active_at = time.monotonic()  # someone is using it: no update restart now (D59)
        if method == "Ask":
            (text,) = params.unpack()
            if not text.strip():
                inv.return_dbus_error(f"{IFACE}.Error.Empty", "nothing to answer")
                return
            task = self.turn_request(text)
            if self.busy and task is None:  # no table: as before
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "still answering; Cancel first")
                return
            self.next_id += 1
            rid = self.next_id
            inv.return_value(GLib.Variant("(u)", (rid,)))
            if task is not None and (self.busy or self.waiting):  # its turn comes after those ahead of it
                self.waiting[task] = (rid, text)
                self.emit("Action", "(ussss)", rid, "queue", "{}", "waiting",
                          json.dumps({"ahead": len(self.waiting) - 1 + (1 if self.busy else 0)}))
                return
            if task is not None:
                self.turns.start(task)
                self.rid_task[rid] = task
            self.ask(rid, text)
        elif method == "ActionAnswer":
            action_id, allow = params.unpack()

            def answer():
                try:
                    p = self.actions.answer(action_id, allow)
                    out, err = json.dumps({"id": p.id, "state": p.state}), None
                except ActionError as e:
                    out, err = None, str(e)
                GLib.idle_add(lambda: (inv.return_dbus_error(f"{IFACE}.Error.Action", err) if err
                                       else inv.return_value(GLib.Variant("(s)", (out,)))) and False)

            threading.Thread(target=answer, daemon=True).start()
        elif method == "UpdateNow":
            if not self.update_ready:
                inv.return_dbus_error(f"{IFACE}.Error.NoUpdate", "no update is waiting")
            elif self.busy or self.loading:
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "still answering; it restarts when it's done")
            elif self.journal is not None:
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "close the journal first (its conversation isn't saved)")
            else:
                inv.return_value(None)
                GLib.timeout_add(300, self.restart_for_update)  # answer the sidebar first, then go
        elif method == "ActionUndo":
            (action_id,) = params.unpack()
            try:
                ok = self.actions.undo(action_id)
            except ActionError as e:
                inv.return_dbus_error(f"{IFACE}.Error.Action", str(e))
                return
            self.emit("ActionCard", "(s)", json.dumps({"id": action_id, "event": "undone" if ok else "undo-failed"}))
            inv.return_value(GLib.Variant("(b)", (ok,)))
        elif method == "StandingAdd":
            wid, topic = params.unpack()
            offer = self.watch_offers.pop(wid, None)
            if offer is None:
                inv.return_dbus_error(f"{IFACE}.Error.NoOffer", "that card has expired; ask again")
                return
            if self.busy:
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "still answering; Cancel first")
                return
            self.next_id += 1
            inv.return_value(GLib.Variant("(u)", (self.next_id,)))
            self.job(self.next_id, lambda on_text, on_action: self.start_watch(offer, topic, on_text, on_action))
        elif method == "TurnList":
            out = self.turns.recent(20) if self.turns is not None else []
            inv.return_value(GLib.Variant("(s)", (json.dumps(out, ensure_ascii=False),)))
        elif method == "TurnCancel":
            (task,) = params.unpack()
            inv.return_value(GLib.Variant("(s)", (json.dumps(self.turn_cancel(int(task))),)))
        elif method in ("HubDownload", "ModelBringIn"):
            a, job = params.unpack()
            if self.busy:
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "still answering; Cancel first")
                return
            self.next_id += 1
            inv.return_value(GLib.Variant("(u)", (self.next_id,)))
            (self.hub_download if method == "HubDownload" else self.bring_in)(self.next_id, a, job)
        elif method in ("ModelsView", "ModelAssign", "ModelRemove", "HubSearch", "HubFiles", "HubCheck", "ModelsOnDrives"):
            args = params.unpack() if params is not None else ()
            threading.Thread(target=self.models_call, args=(method, args, inv), daemon=True).start()
        elif method == "StandingList":
            inv.return_value(GLib.Variant("(s)", (json.dumps(self.standing.listing(), ensure_ascii=False),)))
        elif method == "StandingChange":
            tid, what = params.unpack()
            try:
                task = self.standing.change(tid, what)
            except ValueError:
                inv.return_dbus_error(f"{IFACE}.Error.Invalid", "pause, resume or delete")
                return
            if task is None:
                inv.return_dbus_error(f"{IFACE}.Error.NoTask", "there's no such standing task")
                return
            inv.return_value(GLib.Variant("(s)", (json.dumps(self.standing.listing(), ensure_ascii=False),)))
        elif method in ("KeySet", "KeyForget"):
            args = params.unpack()  # never logged, never put in a reply or the record

            def keep():
                from . import keys
                try:
                    if method == "KeySet":
                        out = {"ok": True, "name": keys.store(args[0], args[1])}
                    else:
                        keys.forget(args[0])
                        out = {"ok": True}
                except Exception as e:  # keys.KeyError_ says what's wrong without the key; the keyring's own errors too
                    out = {"ok": False, "error": str(e) if isinstance(e, keys.KeyError_) else
                           "the login keyring couldn't be reached"}
                GLib.idle_add(lambda: inv.return_value(GLib.Variant("(s)", (json.dumps(out),))) and False)

            threading.Thread(target=keep, daemon=True).start()
        elif method == "ActionList":
            waiting =[self.card(p, "waiting") for p in list(self.actions.open.values())]
            inv.return_value(GLib.Variant("(s)", (json.dumps({"waiting": waiting,
                                                               "recent": self.actions.record.recent(50)},
                                                              ensure_ascii=False),)))
        elif method == "Cancel":
            self.cancel.set()
            interrupt = getattr(self.backend, "interrupt", None)
            if interrupt:
                interrupt()
            inv.return_value(None)
        elif method == "Reset":
            self.guide.reset()
            inv.return_value(None)
        elif method == "Load":
            self.start_load()
            inv.return_value(None)
        elif method == "Decide":
            pid, apply = params.unpack()
            office = self.guide.office

            def work():
                try:
                    if apply:
                        decided, _ = hook.run("office_edit", lambda: office.decide(pid, True),
                                              "apply the prepared edit to the shared document (undo: Ctrl+Z in it)",
                                              reversible=False)
                    else:
                        decided = office.decide(pid, False)
                    out, err = json.dumps(decided, ensure_ascii=False), None
                except OfficeError as e:
                    out, err = None, str(e)
                GLib.idle_add(lambda: (inv.return_dbus_error(f"{IFACE}.Error.Office", err) if err
                                       else inv.return_value(GLib.Variant("(s)", (out,)))) and False)

            if office is None:
                inv.return_dbus_error(f"{IFACE}.Error.Office", "LibreOffice support isn't available")
            else:
                threading.Thread(target=work, daemon=True).start()
        elif method == "ForgetDocument":
            office = self.guide.office
            doc = office.current() if office else None
            if doc:
                office.forget(doc["id"])
            self.refresh_document()
            inv.return_value(None)
        elif method in ("ProjectNew", "ProjectOpen", "ProjectClose", "ProjectList", "ProjectInfo", "ProjectSet",
                        "MakeManuscript"):
            try:
                out = self.project_call(method, *params.unpack())
            except (OSError, ValueError, KeyError) as e:
                inv.return_dbus_error(f"{IFACE}.Error.Project", str(e))
                return
            self.answer(inv, method, out)
        elif method in ("JournalOpen", "JournalClose", "JournalEntries", "JournalSetPin", "JournalRead"):
            try:
                out = self.journal_call(method, *params.unpack())
            except (JournalError, OSError, ValueError) as e:
                inv.return_dbus_error(f"{IFACE}.Error.Journal", str(e))
                return
            self.answer(inv, method, out)
        elif method == "MakeDocument":
            title, text = params.unpack()
            try:
                from . import odt
                folder = os.path.join(os.path.expanduser("~"), "Documents")
                title = (title or "").strip()[:80] or "From the assistant"
                path, _ = hook.run("make_document", lambda: odt.write(folder, title, title, [text], header=""),
                                   "a new Writer document in Documents", created=lambda p: [p])
            except OSError as e:
                inv.return_dbus_error(f"{IFACE}.Error.Document", f"couldn't save the document: {e.strerror or e}")
                return
            self.open_file(path)
            inv.return_value(GLib.Variant("(s)", (json.dumps({"file": path, "shown": "~/" + os.path.relpath(
                path, os.path.expanduser("~"))}, ensure_ascii=False),)))
        elif method == "Search":
            sid, query = params.unpack()
            if self.busy:
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "still answering; Cancel first")
                return
            self.next_id += 1
            inv.return_value(GLib.Variant("(u)", (self.next_id,)))
            if sid in self.chain_offers:  # D91: the Search click a chain was waiting for
                offer = self.chain_offers.pop(sid)
                run = self.run_news_chain if offer.get("recipe") == "news" else self.run_video_chain
                self.job(self.next_id, lambda on_text, on_action: run(offer, query, on_text, on_action))
                return

            def search(on_text, on_action, sid=sid, query=query):
                out, _ = hook.run("web_search", lambda: self.guide.search(sid, query, on_text, on_action, self.cancel),
                                  "a web search (the question left the computer)", reversible=False)
                return {"tool": "web_search", "sources": out["sources"], "reply_chars": len(out["reply"]),
                        "loop_stopped": out.get("loop_stopped", False)}
            self.job(self.next_id, search)
        elif method == "TerminalSend":
            (text,) = params.unpack()
            from . import terminal
            inv.return_value(GLib.Variant("(s)", (json.dumps(terminal.send(text), ensure_ascii=False),)))
        elif method in ("AskImage", "VisionSetup"):
            if self.busy:
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "still answering; Cancel first")
                return
            if method == "AskImage":
                path, request = params.unpack()
                fetch_first = False
            else:
                (oid,) = params.unpack()
                path, request = self.vision_offers.pop(oid, (None, None))
                fetch_first = True
                if path is None:
                    inv.return_dbus_error(f"{IFACE}.Error.Offer", "that offer has expired")
                    return
            self.next_id += 1
            inv.return_value(GLib.Variant("(u)", (self.next_id,)))
            if path == WEB_VIDEO:  # the offer was for the video open in Firefox: read it again, it may have changed
                self.job(self.next_id, lambda on_text, on_action, r=request:
                         self.web_video(r, True, on_text, on_action))
            else:
                self.job(self.next_id, lambda on_text, on_action, p=path, r=request, f=fetch_first:
                         self.look(p, r, f, on_text, on_action))
        elif method == "TerminalSharing":
            (choice,) = params.unpack()
            from . import terminal
            try:
                out = terminal.set_sharing(choice)
            except Exception as e:
                out = {"available": False, "on": False, "open": 0, "error": str(e)}
            inv.return_value(GLib.Variant("(s)", (json.dumps(out),)))
        elif method == "TerminalTry":
            (text,) = params.unpack()
            if self.busy:
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "still answering; Cancel first")
                return
            self.next_id += 1
            inv.return_value(GLib.Variant("(u)", (self.next_id,)))

            def trial(on_text, on_action, cmd=text):
                from . import terminal
                on_action("sandbox", {"command": cmd}, "running", "")
                out, _ = hook.run("try_in_sandbox", lambda: terminal.try_first(cmd),
                                  "try a command in the sandbox (nothing outside it changes)", lane="sandboxed",
                                  reversible=False)
                on_action("sandbox", {"command": cmd}, "done", json.dumps(out, ensure_ascii=False))
                return {"tool": "sandbox", "exit": out.get("exit"), "seconds": out.get("seconds")}
            self.job(self.next_id, trial)
        elif method == "AskBigger":
            (oid,) = params.unpack()
            question = self.bigger_offers.pop(oid, None)
            if self.busy or question is None:
                inv.return_dbus_error(f"{IFACE}.Error.Busy" if self.busy else f"{IFACE}.Error.Offer",
                                      "still answering; Cancel first" if self.busy else "that offer has expired")
                return
            self.next_id += 1
            inv.return_value(GLib.Variant("(u)", (self.next_id,)))
            self.job(self.next_id, lambda on_text, on_action, q=question: self.ask_bigger(q, on_text, on_action))
        elif method == "JournalWrite":
            (private,) = params.unpack()
            if self.busy or self.journal is None:
                inv.return_dbus_error(f"{IFACE}.Error.Journal", "still answering" if self.busy else "the journal isn't open")
                return
            self.next_id += 1
            inv.return_value(GLib.Variant("(u)", (self.next_id,)))
            self.journal_write(self.next_id, private)
        elif method in ("WriteUp", "PlanChapter", "WriteDraft"):
            (arg,) = params.unpack()
            if self.busy:
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "still answering; Cancel first")
                return
            if self.project is None:
                inv.return_dbus_error(f"{IFACE}.Error.Project", "no writing project is open")
                return
            if method == "WriteDraft" and arg not in self.outlines:
                inv.return_dbus_error(f"{IFACE}.Error.Project", "that plan is gone; make a new one")
                return
            self.next_id += 1
            inv.return_value(GLib.Variant("(u)", (self.next_id,)))
            {"WriteUp": self.write_up, "PlanChapter": self.plan_chapter, "WriteDraft": self.write_draft}[method](
                self.next_id, arg)
        elif method in ("ModelOffer", "ModelUse", "ModelDecline"):
            args = params.unpack()
            try:
                if method == "ModelOffer":
                    out = self.model_offer(args[0])
                elif method == "ModelDecline":
                    self.store.decline(args[0])
                    out = None
                else:
                    task, file = args
                    plan = self.store.state()["use"].get(task) or (self.offers.get(task) or (0, None))[1]
                    if not file:  # back to the built-in guide
                        self.store.use(task, None)
                        self.release_writing_model()
                    elif not (plan and plan["file"] == file and self.store.has(file)):
                        raise ValueError("that model isn't downloaded")
                    else:
                        self.store.use(task, {**plan, "measured": plan.get("measured")})
                    out = self.model_offer(task)
            except (OSError, ValueError, KeyError) as e:
                inv.return_dbus_error(f"{IFACE}.Error.Model", str(e))
                return
            self.answer(inv, method, out)
        elif method == "ModelDownload":
            (task,) = params.unpack()
            if self.busy:
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "still answering; Cancel first")
                return
            self.next_id += 1
            inv.return_value(GLib.Variant("(u)", (self.next_id,)))
            self.model_download(self.next_id, task)
        elif method == "Unload":
            if self.busy or self.loading:
                inv.return_dbus_error(f"{IFACE}.Error.Busy", "still answering; Cancel first")
                return
            self.backend.unload()
            self.set_state("off")
            inv.return_value(None)

    def refresh_document(self) -> None:
        office = self.guide.office

        def work():
            doc = office.current() if office else None
            GLib.idle_add(self.set_document, doc["title"] if doc else "")

        threading.Thread(target=work, daemon=True).start()

    def set_document(self, title: str) -> bool:
        if title != self.document:
            self.document = title
            self.changed("Status")
        return False

    # --- work ----------------------------------------------------------------------------------------
    def start_load(self) -> None:
        if self.loading or self.busy or self.backend.status().state == "ready":
            return
        self.loading = True
        self.set_state("loading")

        def work():
            try:
                self.backend.load()
                state = "idle"
            except BackendError as e:
                log(f"load: {e}")
                state = "error"
            GLib.idle_add(self.loaded, state)

        threading.Thread(target=work, daemon=True).start()

    def loaded(self, state: str) -> bool:
        self.loading = False
        if not self.busy:  # a question waiting on this load sets the state itself
            self.set_state(state)
        return False

    def ask(self, rid: int, text: str) -> None:
        from . import keys
        if keys.looks_like_key(text):  # a key pasted into the chat: never to the model, never in the history
            lang = self.guide.tools.lang
            self.job(rid, lambda on_text, on_action: (on_text(keys.PASTED.get(lang, keys.PASTED["en"])),
                                                      {"tool": "key_guard"})[1])
            return
        if self.journal is not None:  # the journal is open: the interviewer asks about the person (D55)
            journal = self.journal

            def interview(on_text, on_action):
                reply = self.interviewer.reply(journal, text, on_text, self.cancel)
                return {"tool": "journal", "reply_chars": len(reply)}
            self.job(rid, interview)
            return
        if self.project is not None:  # a writing project is open: the writing partner gathers (D54)
            project = self.project

            def gather(on_text, on_action):
                reply = self.writer.reply(project, text, on_text, self.cancel)
                return {"tool": "gather", "reply_chars": len(reply), "notes": sum(len(v) for v in project.notes.values())}
            self.job(rid, gather)
            return

        from . import intent, webvideo
        found = intent.video_review(text)
        if found:  # D91: "pull up a video about X (and summarize it)" — a chain, not a web answer
            self.job(rid, lambda on_text, on_action: self.offer_video_chain(text, found, on_text, on_action))
            return
        if intent.driver_request(text):  # update 6: the system's recommended graphics driver, on the Allow card
            self.job(rid, lambda on_text, on_action: self.offer_driver(on_text, on_action))
            return
        watch = intent.watch_request(text)
        if watch is not None:  # D88: "keep me up to date on X" — a standing watch, set up on a card
            self.job(rid, lambda on_text, on_action: self.offer_watch(text, watch, on_text, on_action))
            return
        news = intent.news_request(text)
        if news is not None:  # D91: "pull up the news about X" — recent articles, a short briefing, the sources
            self.job(rid, lambda on_text, on_action: self.offer_news_chain(text, news, on_text, on_action))
            return
        if webvideo.asks_about_video(text):  # the YouTube video open in Firefox (D78), never a summarizer site
            self.job(rid, lambda on_text, on_action: self.web_video(text, False, on_text, on_action))
            return

        def answer(on_text, on_action):
            out = self.guide.turn(text, on_text, on_action, self.cancel)
            from . import terminal
            if terminal.should_offer(text):  # D77: asked once, when it would help
                terminal.offered()
                on_action("terminal_offer", {}, "proposal", json.dumps(terminal.sharing()))
            if out.get("unusual"):  # no help card fits this terminal error: offer the bigger model, if it's here
                plan = self.coding_plan()
                if plan:
                    import uuid
                    oid = uuid.uuid4().hex[:12]
                    self.bigger_offers = {oid: out["unusual"]}  # only the newest offer stands
                    on_action("bigger_model", {}, "proposal", json.dumps({"id": oid, "model": plan["model"]}))
            return {"tool": out["tool"], "args": out["args"], "reply_chars": len(out["reply"]),
                    "timings": out["timings"], "loop_stopped": out.get("loop_stopped", False)}
        self.job(rid, answer)

    # --- reading pictures (D64, D78) ---------------------------------------------------------------------
    def ready_to_see(self, key: str, request: str, moving: bool, speech: bool, fetch_first: bool, on_text,
                     on_action) -> tuple[dict | None, dict, dict | None]:
        """The model that sees, with what it still needs downloaded — asked first (D30), fetched on the second call.
        (choice, inference, None) when ready; (None, inference, result) when the job ends here."""
        from . import video, vision
        inference = config.load()["inference"]
        choice = vision.choose(self.store, inference)
        needed = [m for m in ([choice["projector"]] + ([video.WHISPER] if speech else [])) if not self.store.has(m.file)]
        if not needed:
            return choice, inference, None
        if not fetch_first:
            import uuid
            oid = uuid.uuid4().hex[:12]
            self.vision_offers = {oid: (key, request)}
            on_action("vision_setup", {}, "proposal", json.dumps({
                "id": oid, "model": choice["model"], "size_mb": round(sum(m.size for m in needed) / 2**20),
                "recommended": choice["recommended"], "video": moving,
                "reader": any(m is choice["projector"] for m in needed),
                "speech": any(m is video.WHISPER for m in needed)}))
            return None, inference, {"tool": "vision", "needs": [m.file for m in needed]}
        for m in needed:
            try:
                self.store.download(m, lambda have, total, m=m: on_action(
                    "download", {"file": m.file}, "running", json.dumps({
                        "model": m.name, "have_gb": f"{have / 2**30:.1f}", "total_gb": f"{total / 2**30:.1f}"})),
                    self.cancel)
            except DownloadStopped:
                on_text("Stopped. What was downloaded is kept, so it can carry on later.")
                return None, inference, {"tool": "vision", "done": False}
        return choice, inference, None

    def look(self, path: str, request: str, fetch_first: bool, on_text, on_action) -> dict:
        from . import video, vision
        if not os.path.isfile(path):
            raise BackendError("That file isn't there any more.")
        moving = video.is_video(path)
        choice, inference, ended = self.ready_to_see(path, request, moving, moving, fetch_first, on_text, on_action)
        if ended:
            return ended
        if moving:
            return self.watch(path, request, choice, inference, on_text, on_action)
        close_ups = vision.places(path, request)  # "find the …": where the colours meet, looked at closely
        on_action("vision", {"model": choice["model"], "file": os.path.basename(path), "places": len(close_ups)},
                  "running", "")
        reader = LlamaCppBackend(vision.backend_settings(choice, self.store, inference), log)
        self.backend.unload()  # one card, one model: the guide comes back with the next question
        try:
            reply, timing = reader.chat(vision.messages(path, request, close_ups), max_tokens=1500, on_text=on_text,
                                        cancel=self.cancel, sampling=vision.SAMPLING)
            reduced = reader.status().reduced  # e.g. it ended up on the processor: say so (it was silent once)
        finally:
            reader.unload()
        on_action("vision", {"model": choice["model"]}, "done", json.dumps({
            "model": choice["model"], "recommended": choice["recommended"], "reduced": reduced}))
        return {"tool": "vision", "model": choice["model"], "reply_chars": len(reply), "timings": [timing]}

    def watch(self, path: str, request: str, choice: dict, inference: dict, on_text, on_action) -> dict:
        """A video file: the speech (whisper.cpp), the key frames (ffmpeg), then the shared reading."""
        from . import video
        started = time.monotonic()
        length = video.duration(path)
        work = video.workdir()
        label = os.path.basename(path)
        try:
            self.video_step(choice, label, on_action, "speech", length=video.hms(length))
            lines = video.transcript(path, work, self.store.path(video.WHISPER.file))
            if self.cancel.is_set():
                return {"tool": "video", "done": False}
            self.video_step(choice, label, on_action, "frames")
            frames = video.key_frames(path, work, length)
            return self.read_video(choice, inference, label, request, lines, frames, length, started, on_text,
                                   on_action)
        finally:
            video.cleanup(work)

    # --- chains (D91) ---------------------------------------------------------------------------------------------
    def offer_video_chain(self, text: str, found: dict, on_text, on_action) -> dict:
        """Step 0: say what will happen and show the search; nothing is sent before the Search click (D86)."""
        import uuid
        from . import chains
        sid, query = uuid.uuid4().hex[:12], chains.video_query(found["topic"])
        self.chain_offers = {sid: {**found, "query": query, "question": text}}  # only the newest offer stands
        online = self.guide.tools.online()
        on_action("web_search", {"query": query}, "proposal", json.dumps(
            {"id": sid, "query": query, "online": online, "provider": websearch.PROVIDER}, ensure_ascii=False))
        then = " and summarize it" if found["summarize"] else ""
        on_text(f"I'll look on YouTube for a video about {found['topic']}, open the best match in Firefox{then}. "
                + ("Below is exactly what would be sent; nothing leaves this computer until you click Search."
                   if online else "This computer isn't online right now: connect, then click Search below."))
        return {"tool": "video_review", "proposal": sid}

    def offer_news_chain(self, text: str, news: dict, on_text, on_action) -> dict:
        """Step 0 of the news chain: say what will happen and show the search; nothing sent before the click (D86)."""
        import uuid
        from . import websearch
        from . import newsscan
        sid, query = uuid.uuid4().hex[:12], news["topic"]
        self.chain_offers = {sid: {"recipe": "news", **news, "query": query, "question": text}}
        online = self.guide.tools.online()
        on_action("web_search", {"query": query or "top stories"}, "proposal", json.dumps(
            {"id": sid, "query": query or "top stories", "online": online,
             "provider": news.get("only") or (newsscan.PROVIDERS_WITH_OFFICIAL if query else newsscan.PROVIDERS)},
            ensure_ascii=False))
        lang = self.guide.tools.lang
        what = (say(lang, "news_only", only=news["only"], topic=news["topic"]) if news.get("only") else
                say(lang, "news_all", topic=news["topic"]) if news["topic"] else say(lang, "news_top"))
        on_text(say(lang, "news_offer", what=what) + say(lang, "send_online" if online else "send_offline"))
        return {"tool": "news", "proposal": sid}

    def news_scan(self, topic: str, lang: str, cancel: threading.Event | None = None, person: bool = True,
                  only: str = "") -> dict:
        """D92's three kinds of sources for a topic (no topic: the top stories, press only; only: just that network,
        as the person asked). Each request is recorded as information leaving the computer; a source that fails is
        said, the rest still shown."""
        from . import newsscan, websearch
        cancel = cancel or threading.Event()
        why = "" if person else "a standing task the person set up (D88)"
        out = {"items": [], "posts": None, "failed": [], "found": None, "trouble": "", "needed": [], "only": only}
        if not only:
            out["items"], _ = hook.run("web_search", lambda: newsscan.press(topic, lang),
                                       "a news search (the topic left the computer)", reversible=False, reason=why)
        if topic and not cancel.is_set():  # social: what people post, each line credited to its poster
            (out["posts"], out["failed"]), _ = hook.run(
                "web_search", lambda: newsscan.social(topic, lang, only),
                "a social media search (the topic left the computer)", reversible=False, reason=why)
        if topic and not only and not cancel.is_set():  # official: the subject's own pages (no topic: top stories only)
            try:
                out["found"], _ = hook.run("web_search", lambda: newsscan.official(topic, lang),
                                           "a search for official pages (the topic left the computer)",
                                           reversible=False, reason=why)
            except websearch.SearchError as e:
                out["found"], out["trouble"] = [], say(lang, "official_trouble", e=e)
            more, out["needed"] = newsscan.keyed(topic, lang)  # sources with a key; a missing key is shown as a card
            out["found"] += more
        return out

    @staticmethod
    def scan_links(scan: dict) -> list[tuple[str, str]]:
        return ([(f"{it['outlet']}: {it['title']}", it["url"]) for it in scan["items"]]
                + [(f"{it['who']}: {it['title']}", it["url"]) for it in (scan["posts"] or [])]
                + [(f"{it['source']}: {it['title']}", it["url"]) for it in (scan["found"] or [])])

    @staticmethod
    def scan_report(topic: str, scan: dict, lang: str) -> str:
        from . import newsscan
        return newsscan.report(topic, scan["items"], lang, scan["found"], scan["trouble"], scan["posts"],
                               scan["failed"], scan["needed"], scan.get("only", ""))

    @staticmethod
    def sent_to(topic: str, only: str = "") -> str:
        from . import newsscan
        return only or (newsscan.PROVIDERS_WITH_OFFICIAL if topic else newsscan.PROVIDERS)

    def key_cards(self, needed: list[str], on_action) -> None:
        """The key card for each source the scan skipped: how to get the key, and the box to put it in."""
        from . import keys
        for source in needed:
            on_action("key_needed", {"source": source}, "proposal", json.dumps(keys.card(source), ensure_ascii=False))

    def run_news_chain(self, offer: dict, query: str, on_text, on_action) -> dict:
        """D92: press headlines, social posts, official pages — word for word, attributed and dated; no model."""
        from . import websearch
        topic = ("" if query == "top stories" else (query or offer["topic"])).strip()[:200]
        lang = self.guide.tools.lang
        on_action("web_search", {"query": topic or "top stories"}, "running", "")
        try:
            scan = self.news_scan(topic, lang, self.cancel, only=offer.get("only", ""))
        except websearch.SearchError as e:
            raise BackendError(say(lang, "news_failed", e=e))
        links = self.scan_links(scan)
        on_action("web_search", {"query": topic or "top stories"}, "done", json.dumps(
            {"query": topic, "sources": [{"n": i + 1, "title": t, "url": u} for i, (t, u) in enumerate(links)]},
            ensure_ascii=False))
        reply = self.scan_report(topic, scan, lang)
        on_text(reply)
        self.key_cards(scan["needed"], on_action)
        self.guide.history += [{"role": "user", "content": offer["question"]}, {"role": "assistant", "content": reply}]
        return {"tool": "news", "press": len(scan["items"]), "outlets": len({it["outlet"] for it in scan["items"]}),
                "official": len(scan["found"] or []), "official_trouble": bool(scan["trouble"]),
                "social": len(scan["posts"] or []), "social_failed": len(scan["failed"]), "needs_key": scan["needed"]}

    # --- standing watches (D88) ----------------------------------------------------------------------------------
    def offer_watch(self, text: str, watch: dict, on_text, on_action) -> dict:
        """The setup card: what is sent, to whom, how often. Nothing is set up or sent before the click."""
        import uuid
        wid = uuid.uuid4().hex[:12]
        self.watch_offers = {wid: {**watch, "question": text}}  # only the newest offer stands
        on_action("watch", {"topic": watch["topic"]}, "proposal", json.dumps(
            {"id": wid, "topic": watch["topic"], "at": watch["at"], "only": watch.get("only", ""),
             "provider": self.sent_to(watch["topic"], watch.get("only", "")),
             "online": self.guide.tools.online()}, ensure_ascii=False))
        lang = self.guide.tools.lang
        what = say(lang, "watch_news", topic=watch["topic"]) if watch["topic"] else say(lang, "watch_top")
        if watch.get("only"):
            what = say(lang, "news_only", only=watch["only"], topic=watch["topic"])
        on_text(say(lang, "watch_offer", what=what, at=watch["at"]))
        return {"tool": "watch", "proposal": wid}

    def start_watch(self, offer: dict, topic: str, on_text, on_action) -> dict:
        """Set up the watch and run it once now: everything found is the starting point; later runs show what's new."""
        from . import websearch
        topic = topic.strip()[:200]
        lang = self.guide.tools.lang
        only = offer.get("only", "")
        task = self.standing.add(topic, offer["at"], lang, datetime.datetime.now(), only)
        on_action("web_search", {"query": topic or "top stories"}, "running", "")
        try:
            scan = self.news_scan(topic, lang, self.cancel, only=only)
        except websearch.SearchError as e:
            self.standing.ran(task["id"], datetime.datetime.now(), [], self.sent_to(topic, only), "", str(e))
            raise BackendError(say(lang, "watch_failed", e=e, at=task["at"]))
        shown = scan["items"] + (scan["posts"] or []) + (scan["found"] or [])
        report = self.scan_report(topic, scan, lang)
        self.standing.ran(task["id"], datetime.datetime.now(), shown, self.sent_to(topic, only), report,
                          scan["trouble"])
        links = self.scan_links(scan)
        on_action("web_search", {"query": topic or "top stories"}, "done", json.dumps(
            {"query": topic, "sources": [{"n": i + 1, "title": t, "url": u} for i, (t, u) in enumerate(links)]},
            ensure_ascii=False))
        on_text(say(lang, "watch_set", at=task["at"]) + "\n\n" + report)
        self.key_cards(scan["needed"], on_action)
        return {"tool": "watch", "task": task["id"], "shown": len(shown), "needs_key": scan["needed"]}

    def standing_tick(self) -> bool:
        """Every minute: run the first task whose time has come — never during a question, a load or another run,
        never offline (it tries again next minute)."""
        if self.busy or self.loading or self.standing_running:
            return True
        self.maybe_offer_cuda()
        self.maybe_step_up()
        due = self.standing.due(datetime.datetime.now())
        if not due or not self.guide.tools.online():
            return True
        task = due[0]
        self.standing_running = True

        def work():
            try:
                result = self.run_watch(task)
            except Exception as e:  # recorded with the task; tried again tomorrow at its time
                log(f"standing task {task['id']}: {type(e).__name__}: {e}")
                self.standing.ran(task["id"], datetime.datetime.now(), [],
                                  self.sent_to(task["topic"], task.get("only", "")), "", str(e))
                result = None
            GLib.idle_add(self.standing_done, result)

        threading.Thread(target=work, daemon=True).start()
        return True

    def run_watch(self, task: dict) -> dict | None:
        """One scheduled run: the scan, then only what this watch hasn't shown before."""
        from . import keys
        topic, lang, only = task["topic"], task.get("lang", "en"), task.get("only", "")
        scan = self.news_scan(topic, lang, person=False, only=only)
        fresh = {k: self.standing.fresh(task, scan[k] or []) for k in ("items", "posts", "found")}
        shown = fresh["items"] + fresh["posts"] + fresh["found"]
        scan = {**scan, "items": fresh["items"], "posts": fresh["posts"] if scan["posts"] is not None else None,
                "found": fresh["found"] if scan["found"] is not None else None}
        report = self.scan_report(topic, scan, lang) if shown else ""
        self.standing.ran(task["id"], datetime.datetime.now(), shown, self.sent_to(topic, only), report,
                          scan["trouble"])
        if not shown and not scan["needed"]:
            return None
        return {"id": task["id"], "topic": topic, "lang": lang, "new": len(shown), "report": report,
                "sources": [{"n": i + 1, "title": t, "url": u} for i, (t, u) in enumerate(self.scan_links(scan))],
                "key_cards": [keys.card(k) for k in scan["needed"]]}

    def standing_done(self, result: dict | None) -> bool:
        self.standing_running = False
        if result:
            self.emit("Standing", "(s)", json.dumps(result, ensure_ascii=False))
            if result["new"]:
                lang = result.get("lang", "en")
                what = quoted(result["topic"], lang) if result["topic"] else say(lang, "watch_top")
                self.notify(say(lang, "notify_title"), say(lang, "notify_body", n=result["new"], what=what))
        return False

    def notify(self, title: str, body: str) -> None:
        """A desktop notification (the freedesktop service Cinnamon provides); nothing if there's none."""
        if not self.conn:
            return
        self.conn.call("org.freedesktop.Notifications", "/org/freedesktop/Notifications",
                       "org.freedesktop.Notifications", "Notify",
                       GLib.Variant("(susssasa{sv}i)", ("Cin-MinAI", 0, "cinminai", title, body, [], {}, -1)),
                       None, Gio.DBusCallFlags.NONE, 5000, None, None, None)

    def run_video_chain(self, offer: dict, query: str, on_text, on_action) -> dict:
        """Search YouTube, list the videos, open the first in Firefox, wait for it, summarize it if asked."""
        from . import chains, webvideo, websearch
        query = (query or offer["query"]).strip()[:200]
        on_action("web_search", {"query": query}, "running", "")
        try:
            results, _ = hook.run("web_search", lambda: websearch.search(query, self.guide.tools.lang),
                                  "a web search (the question left the computer)", reversible=False)
        except websearch.SearchError as e:
            raise BackendError(f"The search didn't work: {e}.")
        videos = chains.youtube_videos(results)
        on_action("web_search", {"query": query}, "done", json.dumps(
            {"query": query, "videos": True,
             "sources": [{"n": i + 1, "title": v["title"], "url": v["url"]} for i, v in enumerate(videos)]},
            ensure_ascii=False))
        if not videos:
            on_text("I couldn't find a YouTube video for that. Try other words, or open one in Firefox and ask me "
                    "to summarize it.")
            return {"tool": "video_review", "videos": 0}
        if self.cancel.is_set():
            raise Cancelled("cancelled")
        video = videos[0]
        on_action("open_video", {"title": video["title"]}, "running", "")
        chains.open_in_firefox(video["url"])
        info = chains.wait_for_video(video["id"], self.cancel, webvideo.from_firefox)
        if self.cancel.is_set():
            raise Cancelled("cancelled")
        on_action("open_video", {"title": video["title"]}, "done",
                  json.dumps({"opened": video["title"], "url": video["url"]}, ensure_ascii=False))
        if not offer["summarize"]:
            on_text(f"I opened “{video['title']}” in Firefox. Ask me to summarize it whenever you like; the other "
                    "videos I found are listed above.")
            return {"tool": "video_review", "videos": len(videos), "summarized": False}
        if info is None:
            on_text(f"I opened “{video['title']}” in Firefox, but I couldn't read it yet. When it has loaded, say "
                    "\"summarize this video\".")
            return {"tool": "video_review", "videos": len(videos), "summarized": False}
        if not info.get("transcript"):
            # said before the minutes it takes; the person keeps the choice (Ian, 2026-10-07: let it play as it is)
            on_text("This video has no transcript, so I'm summarizing it from its pictures: that takes a few minutes, "
                    "and small details like quantities can be missed. To use another one, open it from the list and "
                    "say “summarize this video”.\n\n")
        out = self.web_video("summarize this video", False, on_text, on_action)
        return {**out, "tool": "video_review", "videos": len(videos)}

    def web_video(self, request: str, fetch_first: bool, on_text, on_action) -> dict:
        """The YouTube video open in Firefox (D78): its transcript and storyboard, through our extension."""
        from . import video, webvideo
        on_action("video", {"model": "", "file": "Firefox"}, "running", json.dumps({"stage": "asking_firefox"}))
        info = webvideo.from_firefox()
        trouble = webvideo.problem(info)
        if trouble:
            on_text(trouble)
            return {"tool": "web_video", "error": info.get("error") or "unreadable"}
        choice, inference, ended = self.ready_to_see(WEB_VIDEO, request, True, False, fetch_first, on_text, on_action)
        if ended:
            return ended
        started = time.monotonic()
        length = float(info.get("length") or 0)
        label = info.get("title") or "the video"
        work = video.workdir()
        try:
            lines = webvideo.lines(info)
            self.video_step(choice, label, on_action, "pictures", length=video.hms(length), lines=len(lines))
            frames = webvideo.key_frames(info, work)
            if not lines and not frames:
                on_text("I couldn't get this video's transcript or its preview pictures from YouTube, so I can't "
                        "summarize it. Reload the page and ask again.")
                return {"tool": "web_video", "error": "empty"}
            return self.read_video(choice, inference, label, request, lines, frames, length, started, on_text,
                                   on_action, source="youtube", author=info.get("author") or "")
        finally:
            video.cleanup(work)

    @staticmethod
    def video_step(choice: dict, label: str, on_action, stage: str, **more) -> None:
        on_action("video", {"model": choice["model"], "file": label}, "running", json.dumps({"stage": stage, **more}))

    def read_video(self, choice, inference, label, request, lines, frames, length, started, on_text, on_action,
                   source: str = "file", author: str = "") -> dict:
        """The key frames read one by one, then the summary led by the request — each step reported (minutes: the
        lab's 28-minute video took 13)."""
        from . import video, vision
        import base64
        title = label if source == "youtube" else ""  # a file's name isn't a title to trust
        reader = LlamaCppBackend(vision.backend_settings(choice, self.store, inference), log)
        self.backend.unload()  # one card, one model
        try:
            described = []
            for i, (t, f) in enumerate(frames):
                if self.cancel.is_set():
                    return {"tool": "video", "done": False}
                self.video_step(choice, label, on_action, "frame", n=i + 1, of=len(frames), at=video.hms(t))
                with open(f, "rb") as fh:
                    data = base64.b64encode(fh.read()).decode()
                text, _ = reader.chat([{"role": "user", "content": [
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{data}"}},
                    {"type": "text", "text": video.frame_prompt(t, lines, title, author)}]}],
                    max_tokens=200, cancel=self.cancel, sampling=vision.SAMPLING)
                described.append((t, text.strip()))
            from cin_minai.inference import matcher
            prompt = video.summary_prompt(request, lines, described, title, author)
            if not video.fits(prompt, matcher.VISION_CONTEXT, video.SUMMARY_TOKENS):  # a long video: part by part
                stretches = video.parts(lines, described, matcher.VISION_CONTEXT)
                notes = []
                for i, part in enumerate(stretches, 1):
                    if self.cancel.is_set():
                        return {"tool": "video", "done": False}
                    self.video_step(choice, label, on_action, "notes", n=i, of=len(stretches),
                                    at=video.hms(part["start"]))
                    text, _ = reader.chat([{"role": "user", "content": video.notes_prompt(
                        part, i, len(stretches), title, author)}], max_tokens=video.NOTES_TOKENS, cancel=self.cancel,
                        sampling=vision.SAMPLING)
                    notes.append(text)
                prompt = video.summary_from_notes(request, notes, title, author)
            self.video_step(choice, label, on_action, "summary")
            reply, timing = reader.chat([{"role": "user", "content": prompt}],
                                        max_tokens=video.SUMMARY_TOKENS, on_text=on_text, cancel=self.cancel,
                                        sampling=vision.SAMPLING)
            reduced = reader.status().reduced
        finally:
            reader.unload()
        on_action("video", {"model": choice["model"]}, "done", json.dumps({
            "model": choice["model"], "recommended": choice["recommended"], "reduced": reduced,
            "speech": bool(lines), "frames": len(frames), "length": video.hms(length), "source": source,
            "took": video.hms(time.monotonic() - started)}))
        return {"tool": "video", "source": source, "model": choice["model"], "frames": len(frames),
                "speech_lines": len(lines), "reply_chars": len(reply), "timings": [timing]}

    # --- a bigger model for an unusual terminal error (M3; Ian, 2026-10-04: only when no card fits, and asked) ---
    BIGGER_SYSTEM = ("You help a person with an error in their Linux Mint terminal. Say what caused it in plain "
                     "words, then the exact command or steps that fix it, each with what it does. Point out anything "
                     "that changes the system or deletes something. You can't run anything yourself. Reply in the "
                     "person's language, briefly, without headings.")

    def coding_plan(self) -> dict | None:
        """The coding model the person already has on this computer (in use for AICUI, or any downloaded one that
        runs here) — never a download."""
        try:
            plan = self.store.in_use("coding")
            if plan:
                return plan
            machine = matcher.read_machine(models_dir=self.store.root)
            for m in matcher.CATALOG["coding"]:
                p = matcher.plan(m, machine, matcher.CONTEXT["coding"]) if self.store.has(m.file) else None
                if p:
                    return {"model": m.name, "file": m.file, **p, "context": matcher.CONTEXT["coding"],
                            "reserve_mib": matcher.margin_mib(machine.cards[0]) if machine.cards else 0}
        except Exception as e:  # finding a model must never take the answer down
            log(f"coding plan: {type(e).__name__}: {e}")
        return None

    def ask_bigger(self, question: str, on_text, on_action) -> dict:
        plan = self.coding_plan()
        if not plan:
            raise BackendError("The bigger model isn't on this computer any more.")
        on_action("bigger_model", {"model": plan["model"]}, "running", "")
        big = LlamaCppBackend(backend_cfg(config.load()["inference"], plan, self.store.path(plan["file"])), log)
        self.backend.unload()  # the card holds one model: the guide comes back with the next question
        try:
            reply, timing = big.chat([{"role": "system", "content": self.BIGGER_SYSTEM},
                                      {"role": "user", "content": question}],
                                     max_tokens=900, on_text=on_text, cancel=self.cancel)
        finally:
            big.unload()
        on_action("bigger_model", {"model": plan["model"]}, "done", json.dumps({"model": plan["model"]}))
        return {"tool": "bigger_model", "model": plan["model"], "reply_chars": len(reply), "timings": [timing]}

    # --- the writing model (D60) ----------------------------------------------------------------------------
    def writing_cfg(self, plan: dict) -> dict:
        return backend_cfg(config.load()["inference"], plan, self.store.path(plan["file"]))

    def writing_chat(self, messages, **kw):
        plan = self.store.in_use("writing")
        if not plan:
            self.release_writing_model()
            return self.backend.chat(messages, **kw)
        if not self.writing_backend or self.writing_backend[0] != plan["file"]:
            self.release_writing_model()
            self.writing_backend = (plan["file"], LlamaCppBackend(self.writing_cfg(plan), log))
        self.backend.unload()  # the card holds one model: the guide comes back after
        return self.writing_backend[1].chat(messages, **kw)

    def release_writing_model(self) -> None:
        if self.writing_backend:
            self.writing_backend[1].unload()
            self.writing_backend = None

    def model_offer(self, task: str) -> dict:
        """What the matcher would offer for a task, if anything: never the built-in guide, never what's in use or
        what the user declined. The machine is read once every 10 minutes at most."""
        # never read yet = read now. (A default of time 0 hid every offer for the first 10 minutes after a boot: the
        # clock counts from the boot, so "0" looked like a moment ago — Ian's PC, AICUI, 2026-10-07.)
        cached = self.offers.get(task)
        when, plan = cached or (0.0, None)
        if cached is None or time.monotonic() - when > 600:
            m = matcher.read_machine(models_dir=self.store.root)
            plan = matcher.match(m).get(task)
            self.offers[task] = (time.monotonic(), plan)
        used = self.store.in_use(task)
        offer = None
        if plan and plan.get("source") and (not used or used["file"] != plan["file"]) \
                and plan["file"] not in self.store.state()["declined"]:
            offer = {k: plan[k] for k in ("model", "file", "why", "mode", "tok_s", "size")}
            offer["downloaded"] = self.store.has(plan["file"])
            rec = self.store.where(plan["file"]) or {}
            if rec.get("where") == "parked" and rec.get("present"):
                offer["parked_on"] = rec.get("drive") or "another drive"  # copied back, not downloaded
            offer["space_ok"] = offer["downloaded"] or plan["size"] + (2 << 30) <= self.store.free_bytes()
        return {"task": task, "offer": offer, "in_use": used and {k: used.get(k) for k in ("model", "file", "measured")}}

    def model_download(self, rid: int, task: str) -> None:
        plan = (self.offers.get(task) or (0, None))[1]

        def fetch(on_text, on_action):
            if not plan or not plan.get("source"):
                on_text("There's no bigger model to fetch for this on this computer.")
                return {"tool": "model", "done": False}
            m = next(x for ms in matcher.CATALOG.values() for x in ms if x.file == plan["file"])
            gb = lambda b: f"{b / 2**30:.1f}"  # noqa: E731
            try:
                hook.run("download_model", lambda: self.store.download(m, lambda have, total: on_action(
                    "download", {"file": m.file}, "running",
                    json.dumps({"model": m.name, "have_gb": gb(have), "total_gb": gb(total)})), self.cancel),
                    f"download the model {m.name} from Hugging Face (checked before use)", reversible=False,
                    private=False)
            except DownloadStopped:
                on_text("Stopped. What was downloaded is kept, so it can carry on later.")
                return {"tool": "model", "done": False}
            on_action("download", {"file": m.file}, "running", json.dumps({"model": m.name, "testing": True}))
            self.store.use(task, {**plan, "measured": None})
            try:
                speed = benchmark(self.writing_chat)  # loads it the way writing will
            except Exception as e:  # it doesn't run here after all: back to the guide, and say so
                self.store.use(task, None)
                self.release_writing_model()
                on_text(f"{m.name} downloaded and checked, but it didn't start on this computer ({e}). "
                        "Writing stays with the built-in guide.")
                return {"tool": "model", "done": False}
            self.store.use(task, {**plan, "measured": round(speed, 1)})
            on_action("download", {"file": m.file}, "done", json.dumps({"model": m.name, "measured": round(speed, 1)}))
            on_text(f"{m.name} is ready: downloaded, checked against its checksum, and tested here at "
                    f"{speed:.0f} tokens a second (about {speed * 45:.0f} words a minute). Writing uses it from now on; "
                    "you can switch back to the built-in guide in Notes.")
            return {"tool": "model", "done": True, "measured": speed}
        self.job(rid, fetch)

    # --- writing projects (D54) -------------------------------------------------------------------------
    def project_call(self, method: str, *args):
        if method in ("ProjectNew", "ProjectOpen"):
            self.journal = None  # one mode at a time
        if method == "ProjectNew":
            self.project = Project.new(args[0] or "Untitled", "story")
        elif method == "ProjectOpen":
            folder = os.path.realpath(args[0])
            if os.path.dirname(folder) != os.path.realpath(PROJECTS):
                raise ValueError("not a writing project folder")
            self.project = Project.open(folder)
        elif method == "ProjectClose":
            self.release_writing_model()
            self.project = None
            self.outlines.clear()
            self.changed("Status")
            return None
        elif method == "ProjectList":
            return Project.list()
        elif method == "MakeManuscript":  # our code only, no model: quick, so no job (D58)
            if self.project is None:
                raise ValueError("no writing project is open")
            o = json.loads(args[0] or "{}")
            res = manuscript.make(self.project, str(o.get("author", "")), str(o.get("contact", "")))
            self.open_file(res["odt"])
            return res
        elif method == "ProjectSet":
            if self.project is None:
                raise ValueError("no writing project is open")
            s = json.loads(args[0] or "{}")
            self.project.set_shape(s.get("shape"), s.get("chapters"), s.get("next_chapter"))
        if method != "ProjectInfo":
            self.outlines.clear()  # a plan was for the shape and chapter it was made for
            self.changed("Status")
        p = self.project
        if p is None:
            return None
        chapter, steps = p.this_chapter()
        return {"title": p.title, "folder": p.folder, "notes": p.notes, "drafts": p.data["drafts"],
                "messages": len(p.data["messages"]), "circle": p.circle, "shape": p.data["shape"],
                "chapters": p.data["chapters"], "next_chapter": chapter, "next_steps": list(steps),
                "steps": [{"key": k, "name": n, "means": m} for k, n, m, _ in CIRCLE]}

    # --- the journal (D55) -----------------------------------------------------------------------------
    def journal_call(self, method: str, *args):
        if method == "JournalOpen":
            self.project, self.journal = None, Journal()
            self.changed("Status")
            return {"entries": len(self.journal.entries()), "has_pin": self.journal.has_pin}
        if method == "JournalClose":
            self.journal = None  # today's conversation goes with it: it was never on disk
            self.changed("Status")
            return None
        j = self.journal or Journal()
        if method == "JournalEntries":
            return {"entries": j.entries(), "has_pin": j.has_pin}
        if method == "JournalSetPin":
            j.set_pin(args[0], args[1])
            return None
        return j.read_private(args[0], args[1])  # JournalRead

    def journal_write(self, rid: int, private: bool) -> None:
        journal = self.journal

        def write(on_text, on_action):
            import datetime as dt
            when = dt.datetime.now().astimezone()
            try:
                title, text = self.interviewer.entry(journal, when, self.cancel)
                e = journal.write(title, text, when, private)
            except JournalError as err:
                on_text(str(err)[0].upper() + str(err)[1:] + ".")
                return {"tool": "journal_write", "written": False}
            on_action("journal", {"private": private}, "done",
                      json.dumps({k: e[k] for k in ("file", "title", "when", "private", "words")}, ensure_ascii=False))
            journal.messages.clear()  # written: today's conversation is done
            if private:
                on_text(f"Today's entry is written and locked with your PIN ({e['words']} words). Open it from "
                        "Entries with your PIN; I can't read it while it's locked.")
            else:
                self.open_file(e["path"])
                on_text(f"Today's entry, \"{e['title']}\", is written ({e['words']} words) and open in Writer. It's in "
                        "Documents/Journal.")
            return {"tool": "journal_write", "written": True, "private": private}
        self.job(rid, write)

    def write_up(self, rid: int, wish: str) -> None:
        """The review before every chapter (D57)."""
        project = self.project

        def review(on_text, on_action):
            r = self.writer.review(project, self.cancel)
            on_action("review", {}, "proposal", json.dumps(r, ensure_ascii=False))
            what = f"chapter {r['chapter']}" if r.get("chapter") else "the story"
            asks = len(r.get("questions", []))
            on_text(f"Here's where the story stands before {what}. "
                    + (f"I have {asks} question{'s' if asks != 1 else ''} for you. " if asks else "")
                    + "Answer or add anything you like, then click Plan the chapter.")
            return {"tool": "review", "questions": asks, "next_steps": r["next_steps"]}
        self.job(rid, review)

    def plan_chapter(self, rid: int, arg: str) -> None:
        """arg: the writer's answers as text, or JSON {"answers": text, "written": [steps they ticked]} from the
        review card (D57: their ticks decide where the chapter starts)."""
        project = self.project
        try:
            a = json.loads(arg) if arg.lstrip().startswith("{") else None
        except ValueError:
            a = None
        answers, written = (str(a.get("answers", "")), a.get("written")) if isinstance(a, dict) else (arg, None)

        def plan(on_text, on_action):
            if answers.strip():  # the writer's words become notes: they decide (D57)
                project.remember("user", answers.strip())
                self.writer.take_notes(project, answers, self.cancel)
            r = project.data.get("review")
            if r is None or r.get("chapter") != project.this_chapter()[0]:
                r = self.writer.review(project, self.cancel)
            if isinstance(written, list):
                r = self.writer.set_written(project, r, written)
            outline = self.writer.outline(project, answers, self.cancel, review=r)
            oid = f"o{rid}"
            self.outlines = {oid: outline}  # only the newest plan can be written
            on_action("outline", {"answers": answers}, "proposal", json.dumps({**outline, "id": oid}, ensure_ascii=False))
            what = (f"chapter {outline['chapter']} of {outline['of']}, \"{outline['chapter_title']}\", "
                    f"{len(outline['scenes'])} scenes for the steps {', '.join(s.title() for s in outline['steps'])}"
                    if outline.get("chapter") else
                    f"\"{outline['chapter_title']}\": the whole story circle in {len(outline['scenes'])} scenes")
            on_text(f"Here's a plan for {what}. Click Write it to write the draft, or say what should change and "
                    "click Plan again.")
            return {"tool": "outline", "scenes": len(outline["scenes"])}
        self.job(rid, plan)

    def write_draft(self, rid: int, oid: str) -> None:
        project, outline = self.project, self.outlines[oid]

        def write(on_text, on_action):
            cookie = self.inhibit_sleep(True)  # a sleeping screen left the 1080 Ti 6x slower (2026-10-01)
            try:
                res = self.writer.draft(project, outline, lambda n, total, what: on_action(
                    "draft", {"scene": n, "of": total}, "running", json.dumps({"scene": n, "of": total, "title": what},
                                                                              ensure_ascii=False)), self.cancel)
            finally:
                self.inhibit_sleep(False, cookie)
            if res.get("file"):
                rel = os.path.relpath(res["file"], os.path.expanduser("~"))
                on_action("draft", {}, "done", json.dumps({**res, "shown": "~/" + rel}, ensure_ascii=False))
                self.open_file(res["file"])
                pages = -(-res["lines"] // 28)
                on_text(("I stopped as you asked. " if res["stopped"] else "") +
                        f"The rough draft is ready: {res['scenes']} scenes, about {res['words']} words "
                        f"(roughly {pages} pages). It's open in Writer and saved as ~/{rel}.")
            else:
                on_text("Stopped before anything was written.")
            return {"tool": "draft", **{k: res.get(k) for k in ("scenes", "words", "lines", "stopped")}}
        self.job(rid, write)

    def inhibit_sleep(self, on: bool, cookie: int = 0) -> int:
        """Keep the screen awake during a long job (org.gnome.SessionManager, which Cinnamon's session provides)."""
        try:
            bus = Gio.bus_get_sync(Gio.BusType.SESSION)
            if on:
                v = bus.call_sync("org.gnome.SessionManager", "/org/gnome/SessionManager", "org.gnome.SessionManager",
                                  "Inhibit", GLib.Variant("(susu)", ("cinminai-daemon", 0, "Writing a draft", 8)),
                                  None, Gio.DBusCallFlags.NONE, 3000, None)
                return v.unpack()[0]
            if cookie:
                bus.call_sync("org.gnome.SessionManager", "/org/gnome/SessionManager", "org.gnome.SessionManager",
                              "Uninhibit", GLib.Variant("(u)", (cookie,)), None, Gio.DBusCallFlags.NONE, 3000, None)
        except GLib.Error as e:
            log(f"screen-sleep inhibit: {e.message}")
        return 0

    @staticmethod
    def open_file(path: str) -> None:
        try:
            Gio.AppInfo.launch_default_for_uri(Gio.File.new_for_path(path).get_uri(), None)
        except GLib.Error as e:
            log(f"open {path}: {e.message}")

    # --- jobs -------------------------------------------------------------------------------------------
    def job(self, rid: int, fn) -> None:
        """Run fn(on_text, on_action) -> stats on a worker thread: one at a time, cancellable, never silent."""
        self.busy = True
        self.active_at = time.monotonic()
        self.cancel.clear()
        self.set_state("loading" if self.backend.status().state != "ready" else "thinking")

        def on_text(piece: str) -> None:
            GLib.idle_add(self.emit, "Token", "(us)", rid, piece)
            if self.state != "thinking":
                GLib.idle_add(self.set_state, "thinking")

        # ReplyGuard uses this only after Token pieces have exposed a loop.  Queueing
        # Replace after them makes the sidebar show exactly the repaired final reply.
        on_text.replace = lambda text: GLib.idle_add(self.emit, "Replace", "(us)", rid, text)

        def on_action(tool: str, args: dict, state: str, result: str) -> None:
            GLib.idle_add(self.emit, "Action", "(ussss)", rid, tool,
                          json.dumps(args, ensure_ascii=False), state, result)

        def work():
            t0 = time.monotonic()
            error, stats = None, {}
            try:
                stats = fn(on_text, on_action)
            except Cancelled:
                stats = {"cancelled": True}
            except BackendError as e:
                error = str(e)
            except Exception as e:  # never leave the sidebar waiting
                log(f"turn failed: {type(e).__name__}: {e}")
                error = "Something went wrong while answering. Please try again."
            stats["seconds"] = round(time.monotonic() - t0, 2)
            GLib.idle_add(self.finish, rid, error, stats)

        threading.Thread(target=work, daemon=True).start()

    def finish(self, rid: int, error: str | None, stats: dict) -> bool:
        self.active_at = time.monotonic()
        self.busy = False
        self.last_stats = json.dumps(stats, ensure_ascii=False)
        if error:
            self.emit("Error", "(us)", rid, error)
        self.set_state("error" if error and self.backend.status().state == "error" else
                       "idle" if self.backend.status().state == "ready" else "off")
        self.changed("LastStats", "Model", "Status")
        self.emit("Done", "(u)", rid)
        self.turn_finished(rid, error, stats)
        return False

    # --- turn tokens (SPEC §22.4) --------------------------------------------------------------------------
    def turn_request(self, text: str) -> int | None:
        if self.turns is None:
            return None
        try:
            return self.turns.request(text)
        except Exception as e:  # the record never stops an answer
            log(f"turn table: {type(e).__name__}: {e}")
            return None

    def turn_finished(self, rid: int, error: str | None, stats: dict) -> None:
        task = self.rid_task.pop(rid, None)
        if self.turns is None:
            return
        try:
            ctx = self.backend.status().context
            if ctx and ctx != self.turn_ctx:  # the guide's size cap follows where it runs
                self.turn_ctx = ctx
                self.turns.guide_context(ctx)
            if task is not None:
                state = "cancelled" if stats.get("cancelled") else "failed" if error else "done"
                model = self.backend.status().model or ""
                self.turns.finish(task, state, error or str(stats.get("tool") or ""), model=model)
        except Exception as e:
            log(f"turn table: {type(e).__name__}: {e}")
        if self.waiting:
            GLib.idle_add(self.next_turn)

    def models_call(self, method: str, args: tuple, inv) -> None:
        """ModelsView / ModelAssign off the main loop: reading the machine and the models' headers takes a moment."""
        from . import hub, jobs
        guide = config.load()["inference"].get("model", "")
        try:
            if method == "ModelsView":
                out = jobs.view(self.store, guide)
            elif method == "ModelAssign":
                out = jobs.assign(self.store, args[0], args[1], guide)
            elif method == "ModelRemove":
                out = jobs.remove(self.store, args[0])
            else:
                out = self.hub_call(method, args)
        except Exception as e:
            if isinstance(e, (jobs.JobError, hub.HubError)):
                msg = str(e)
            else:
                log(f"models view: {type(e).__name__}: {e}")
                msg = "couldn't read the models here"
            GLib.idle_add(lambda: inv.return_dbus_error(f"{IFACE}.Error.Model", msg) and False)
            return
        if method == "ModelAssign":
            log(f"job {args[0]}: " + (f"our pick again ({out.get('model', '')})" if out.get("ours") else out["model"]))
        GLib.idle_add(lambda: inv.return_value(GLib.Variant("(s)", (json.dumps(out, ensure_ascii=False),))) and False)

    def answer(self, inv, method: str, out) -> None:
        """A method's reply as its declaration says: one declared to answer always does — null when there's nothing
        (2026-10-11: ProjectInfo with no writing project open returned nothing, and the sidebar got a D-Bus error);
        one declared without an answer gets none."""
        if OUT_ARGS.get(method):
            inv.return_value(GLib.Variant("(s)", (json.dumps(out, ensure_ascii=False),)))
        else:
            inv.return_value(None)

    def hub_call(self, method: str, args: tuple):
        """Searching Hugging Face, a repository's files, the fit check, and models on connected drives."""
        from . import hub
        if method == "HubSearch":
            return hub.search(args[0])
        if method == "HubFiles":
            found = hub.files(args[0])
            self.hub_found[found["repo"]] = found
            return found
        machine = matcher.read_machine(models_dir=self.store.root)
        if method == "HubCheck":
            repo, path = args
            found = self.hub_found.get(repo)
            f = next((x for x in (found or {}).get("files", []) if x["path"] == path), None)
            if f is None:
                raise hub.HubError("look at the repository's files first")
            m = hub.model_for(repo, found["revision"], f)
            self.hub_checked[m.file] = m
            return {"repo": repo, "file": m.file, "model": m.name, "size": m.size, "licence": found["licence"],
                    "gated": found["gated"], "here": self.store.has(m.file), "free_bytes": self.store.free_bytes(),
                    "jobs": hub.fit(m, machine)}
        out = []  # ModelsOnDrives
        for d in hub.on_drives():
            try:
                m = matcher.model_from_gguf(d["path"])
            except Exception:  # not a model llama.cpp reads: listed, never offered
                out.append({**d, "model": d["file"], "jobs": {}})
                continue
            out.append({**d, "model": m.name, "here": self.store.has(d["file"]), "jobs": hub.fit(m, machine)})
        self.drive_models = {d["path"] for d in out}
        return out

    def speed_test(self, m, job: str) -> tuple[dict, float]:
        """Load the model the way its job will and measure it (the matcher only estimates)."""
        from . import jobs
        machine = matcher.read_machine(models_dir=self.store.root)
        plan = jobs.job_plan(m, machine, job or "coding")
        if plan is None:
            raise BackendError("it doesn't fit on this computer now")
        big = LlamaCppBackend(backend_cfg(config.load()["inference"], plan, self.store.path(m.file)), log)
        self.backend.unload()  # the card holds one model: the guide comes back with the next question
        self.release_writing_model()
        try:
            return plan, benchmark(big.chat)
        finally:
            big.unload()

    def model_ready(self, m, job: str, on_text, on_action) -> dict:
        """After a download or a copy: test it here, then give it the job (if one was chosen)."""
        from . import jobs
        on_action("download", {"file": m.file}, "running", json.dumps({"model": m.name, "testing": True}))
        try:
            _, speed = self.speed_test(m, job)
        except Exception as e:  # kept: the person decides whether to delete it
            on_text(f"{m.name} is on this computer, but it didn't start here ({e}). Nothing was changed; you can "
                    "remove it from the Models view.")
            return {"tool": "model", "done": False}
        if job:
            jobs.assign(self.store, job, m.file, config.load()["inference"].get("model", ""))
            self.store.use(job, {**self.store.state()["use"][job], "measured": round(speed, 1)})
        on_action("download", {"file": m.file}, "done", json.dumps({"model": m.name, "measured": round(speed, 1)}))
        on_text(f"{m.name} is ready: tested here at {speed:.0f} tokens a second (about {speed * 45:.0f} words a "
                "minute). " + (f"It does that job from now on; the Models view switches it back."
                               if job else "Give it a job in the Models view."))
        return {"tool": "model", "done": True, "measured": speed}

    def hub_download(self, rid: int, file: str, job: str) -> None:
        m = self.hub_checked.get(file)
        gb = lambda b: f"{b / 2**30:.1f}"  # noqa: E731

        def fetch(on_text, on_action):
            if m is None:
                on_text("Check that model first: the Models view looks at whether it runs here before fetching it.")
                return {"tool": "model", "done": False}
            rec = self.store.where(m.file) or {}
            if self.store.has(m.file) and rec.get("source") != m.source:
                on_text(f"A different model called {m.file} is already in the model folder, so this one wasn't "
                        "fetched.")
                return {"tool": "model", "done": False}
            repo = m.source.partition("@")[0]
            try:
                hook.run("download_model", lambda: self.store.download(m, lambda have, total: on_action(
                    "download", {"file": m.file}, "running",
                    json.dumps({"model": m.name, "have_gb": gb(have), "total_gb": gb(total)})), self.cancel),
                    f"download the model {m.name} from huggingface.co/{repo} (checked before use)",
                    reversible=False, private=False)
            except DownloadStopped:
                on_text("Stopped. What was downloaded is kept, so it can carry on later.")
                return {"tool": "model", "done": False}
            return self.model_ready(m, job, on_text, on_action)
        self.job(rid, fetch)

    def bring_in(self, rid: int, path: str, job: str) -> None:
        """Copy a model from a connected drive into the model folder (only one ModelsOnDrives listed)."""
        gb = lambda b: f"{b / 2**30:.1f}"  # noqa: E731

        def copy(on_text, on_action):
            if path not in getattr(self, "drive_models", set()) or not os.path.isfile(path):
                on_text("That model isn't on a connected drive any more.")
                return {"tool": "model", "done": False}
            m = matcher.model_from_gguf(path)
            if self.store.has(m.file):
                on_text(f"{m.file} is already in the model folder.")
                return self.model_ready(m, job, on_text, on_action)
            if m.size + (2 << 30) > self.store.free_bytes():
                on_text(f"There isn't room for it: {m.size / 2**30:.1f} GB needed.")
                return {"tool": "model", "done": False}
            try:
                self.store._copy_checked(path, self.store.path(m.file), "", lambda have, total: on_action(
                    "download", {"file": m.file}, "running",
                    json.dumps({"model": m.name, "have_gb": gb(have), "total_gb": gb(total), "copy": True})),
                    self.cancel)
            except DownloadStopped:
                part = self.store.path(m.file) + ".part"
                if os.path.exists(part):
                    os.remove(part)
                on_text("Stopped; nothing was kept.")
                return {"tool": "model", "done": False}
            self.store.record(m, "store")
            return self.model_ready(m, job, on_text, on_action)
        self.job(rid, copy)

    def turn_cancel(self, task: int) -> dict:
        """Stop from the Requests view: a waiting request never starts (its asker is told); the running one stops
        like the Stop button; the table cancels the task and everything under it."""
        if self.turns is None:
            return {"cancelled": 0}
        root = (self.turns.db.task_tree(task) or {}).get("id", task)
        for t in list(self.waiting):
            if t in (task, root):
                rid, _ = self.waiting.pop(t)
                self.emit("Error", "(us)", rid, "Stopped before it started.")
                self.emit("Done", "(u)", rid)
        if any(t in (task, root) for t in self.rid_task.values()):
            self.cancel.set()
            interrupt = getattr(self.backend, "interrupt", None)
            if interrupt:
                interrupt()
        return {"cancelled": self.turns.cancel(task)}

    def next_turn(self) -> bool:
        """The next waiting request, in the table's order (the person's first)."""
        if self.busy or not self.waiting:
            return False
        try:
            task = self.turns.next()
        except Exception as e:
            log(f"turn table: {type(e).__name__}: {e}")
            task = next(iter(self.waiting))
        if task is None or task not in self.waiting:
            task = next(iter(self.waiting))  # the table and the queue disagree: oldest first
        rid, text = self.waiting.pop(task)
        self.rid_task[rid] = task
        self.ask(rid, text)
        return False



def run(backend: InferenceBackend, guide: Guide, preload: bool) -> None:
    loop = GLib.MainLoop()
    svc = Service(loop, backend, guide, preload)
    Gio.bus_own_name(Gio.BusType.SESSION, NAME, Gio.BusNameOwnerFlags.NONE, svc.acquired, None, svc.lost)
    try:
        loop.run()
    finally:
        backend.unload()
